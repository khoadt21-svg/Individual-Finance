import React, { useState, useEffect } from 'react';
import { Transaction, Category, Event } from '../types';
import { Search } from 'lucide-react';

interface TransactionLedgerProps {
  transactions: Transaction[];
  categories: Category[];
  events: Event[];
  selectedMonth: number;
  setSelectedMonth: (month: number) => void;
  selectedYear: number;
  setSelectedYear: (year: number) => void;
  onEditTransaction: (id: string, updatedTx: Omit<Transaction, 'id'>) => void;
  onDeleteTransaction: (id: string) => void;
  setScreen: (screen: 'EVENT_OVERVIEW' | 'LOG_TRANSACTION' | 'TRANSACTION_LEDGER' | 'EVENT_BUDGET_PLANNER' | 'EVENT_BUDGET_DETAIL' | 'MANAGE_EVENTS' | 'MANAGE_CATEGORIES' | 'YEARLY_SUMMARY') => void;
  onMenuClick?: () => void;
}

const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

const MONTH_SHORTS = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
];

export default function TransactionLedger({
  transactions,
  categories,
  events,
  selectedMonth,
  setSelectedMonth,
  selectedYear,
  setSelectedYear,
  onEditTransaction,
  onDeleteTransaction,
  setScreen,
  onMenuClick
}: TransactionLedgerProps) {
  // Filters State
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'income' | 'expense'>('all');
  const [selectedEventId, setSelectedEventId] = useState<string>('all'); // 'all' = All Events

  // Editing modal states
  const [editingTx, setEditingTx] = useState<Transaction | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editAmount, setEditAmount] = useState<number>(0);
  const [editType, setEditType] = useState<'income' | 'expense'>('expense');
  const [editCategoryId, setEditCategoryId] = useState('');
  const [editEventId, setEditEventId] = useState('');
  const [editDate, setEditDate] = useState('');
  const [editVendor, setEditVendor] = useState('');
  const [editCurrency, setEditCurrency] = useState('USD');
  const [editNote, setEditNote] = useState('');
  const [editIsRecurring, setEditIsRecurring] = useState(false);
  const [editFrequency, setEditFrequency] = useState<'weekly' | 'monthly' | 'yearly'>('monthly');

  // Deleting confirmation dialog state
  const [deletingTxId, setDeletingTxId] = useState<string | null>(null);

  // Sync edits when editingTx changes
  useEffect(() => {
    if (editingTx) {
      setEditTitle(editingTx.title);
      setEditAmount(editingTx.amount);
      setEditType(editingTx.type);
      setEditCategoryId(editingTx.categoryId);
      setEditEventId(editingTx.eventId || '');
      setEditDate(editingTx.date);
      setEditVendor(editingTx.vendor || '');
      setEditCurrency(editingTx.currency || 'USD');
      setEditNote(editingTx.note || '');
      setEditIsRecurring(editingTx.isRecurring || false);
      setEditFrequency(editingTx.frequency || 'monthly');
    }
  }, [editingTx]);

  // Helper to check if an event is in the selected period (Month & Year) for dropdown filtering
  const isEventInPeriod = (evt: Event) => {
    const range = evt.dateRange.toLowerCase();
    
    // Always include 'ongoing' events for any selected period
    if (range.includes('ongoing')) return true;

    if (selectedMonth !== 0) {
      const currentMonthName = MONTH_NAMES[selectedMonth - 1];
      const currentMonthShort = MONTH_SHORTS[selectedMonth - 1];
      const hasMonth = range.includes(currentMonthName.toLowerCase()) || range.includes(currentMonthShort.toLowerCase());
      if (!hasMonth) return false;
    }

    if (selectedYear !== 0) {
      const currentYear = selectedYear.toString();
      const hasYear = range.includes(currentYear.toLowerCase());
      if (!hasYear) return false;
    }

    return true;
  };

  const filteredEventsForDropdown = events.filter(isEventInPeriod);

  // Automatically reset selectedEventId to 'all' if the selected event is not in the filtered dropdown
  useEffect(() => {
    if (selectedEventId !== 'all') {
      const exists = filteredEventsForDropdown.some(evt => evt.id === selectedEventId);
      if (!exists) {
        setSelectedEventId('all');
      }
    }
  }, [selectedMonth, selectedYear, events, selectedEventId]);

  // Filter transactions
  const filteredTxs = transactions.filter((tx) => {
    const matchesSearch = tx.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
      (tx.vendor && tx.vendor.toLowerCase().includes(searchTerm.toLowerCase())) || 
      (tx.note && tx.note.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesType = filterType === 'all' || tx.type === filterType;
    
    const matchesEvent = selectedEventId === 'all' || tx.eventId === selectedEventId;
    
    let matchesPeriod = true;
    if (selectedYear !== 0 || selectedMonth !== 0) {
      const parts = tx.date.split('-');
      if (parts.length === 3) {
        const txYear = parseInt(parts[0], 10);
        const txMonth = parseInt(parts[1], 10);
        if (selectedYear !== 0 && txYear !== selectedYear) matchesPeriod = false;
        if (selectedMonth !== 0 && txMonth !== selectedMonth) matchesPeriod = false;
      } else {
        matchesPeriod = false;
      }
    }

    return matchesSearch && matchesType && matchesEvent && matchesPeriod;
  });

  const getCategoryIcon = (catId: string) => {
    const category = categories.find((c) => c.id === catId);
    if (category) {
      switch (category.icon) {
        case 'Home': return 'home';
        case 'ShoppingCart': return 'shopping_cart';
        case 'Car': return 'directions_car';
        case 'Utensils': return 'restaurant';
        case 'Film': return 'movie';
        case 'Zap': return 'bolt';
        case 'HeartPulse': return 'medical_services';
        case 'Checkroom': return 'checkroom';
        case 'Payments': return 'payments';
        case 'ShowChart': return 'show_chart';
        case 'Savings': return 'savings';
        case 'Book': return 'menu_book';
        case 'Flight': return 'flight';
        case 'Work': return 'work';
        case 'Pets': return 'pets';
        case 'Gift': return 'card_giftcard';
        case 'Music': return 'music_note';
        case 'Coffee': return 'local_cafe';
        case 'MoreHorizontal': return 'more_horiz';
        default: return 'category';
      }
    }

    switch (catId) {
      case 'cat-housing': return 'home';
      case 'cat-groceries': return 'local_grocery_store';
      case 'cat-transport': return 'local_gas_station';
      case 'cat-dining': return 'restaurant';
      case 'cat-entertainment': return 'shopping_bag';
      case 'cat-utilities': return 'bolt';
      case 'cat-health': return 'medical_services';
      default: return 'payments';
    }
  };

  // Group transactions by date
  const groupTransactions = () => {
    const groups: { [key: string]: Transaction[] } = {};
    const todayStr = new Date().toISOString().split('T')[0];
    
    // Simple helper to decide header label
    const getHeaderLabel = (dateStr: string) => {
      if (dateStr === todayStr) return 'Today';
      if (dateStr === '2026-06-01') return 'Today';
      if (dateStr === '2026-05-31') return 'Yesterday';
      
      const dateParts = dateStr.split('-');
      if (dateParts.length === 3) {
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const monthIndex = parseInt(dateParts[1], 10) - 1;
        return `${months[monthIndex]} ${dateParts[2]}, ${dateParts[0]}`;
      }
      return dateStr;
    };

    filteredTxs.forEach((tx) => {
      const label = getHeaderLabel(tx.date);
      if (!groups[label]) {
        groups[label] = [];
      }
      groups[label].push(tx);
    });

    return groups;
  };

  const txGroups = groupTransactions();

  // Handle transaction edit submit
  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTx) return;
    if (!editTitle.trim()) return;
    if (editAmount <= 0) return;

    onEditTransaction(editingTx.id, {
      title: editTitle,
      amount: editAmount,
      type: editType,
      categoryId: editCategoryId,
      eventId: editEventId,
      date: editDate,
      vendor: editVendor,
      currency: editCurrency,
      note: editNote,
      isRecurring: editIsRecurring,
      frequency: editIsRecurring ? editFrequency : undefined
    });

    setEditingTx(null);
  };

  // Handle transaction delete confirm
  const handleDeleteConfirm = () => {
    if (!deletingTxId) return;
    onDeleteTransaction(deletingTxId);
    setDeletingTxId(null);
  };

  return (
    <div className="bg-slate-50 text-slate-900 min-h-screen pb-32">
      {/* TopAppBar */}
      <header className="bg-white border-b border-slate-200/80 w-full sticky top-0 z-40 shadow-xs">
        <div className="flex flex-col sm:flex-row justify-between items-stretch sm:items-center px-4 md:px-8 py-3 sm:py-0 min-h-[5rem] sm:h-20 gap-3 w-full max-w-[1200px] mx-auto">
          <div className="flex items-center gap-2 md:gap-3">
            {onMenuClick && (
              <button
                onClick={onMenuClick}
                className="md:hidden text-slate-500 hover:bg-slate-100 p-2 rounded-full cursor-pointer flex items-center justify-center -ml-1 mr-1 shrink-0"
                aria-label="Open navigation menu"
              >
                <span className="material-symbols-outlined text-[24px]">menu</span>
              </button>
            )}
            <img
              alt="User"
              className="w-10 h-10 rounded-full object-cover border border-slate-200 shrink-0"
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuDdOtAhJSOKb9gzZf_szXoECMHFsBRaC3a0ijsRebAHRg7UhmNN56GFu1-nkojeRxAjAByME7M8Csm12mFZTaTYqR_LydyRGbzzV6PR_Pny-OMMobQMelTsjETFraJrsLNZ01CNSfLHIgq86bsubYrGsCmOlvfz8-PRiyNXQiixUEDjFoq13XPW8E7LLPjtB2PdWpt8vJmvFHVvt7rkS2yjXVzaGXjXzPtwWlPXwLpL8f0-PfFIggSxbaXrNi5QlAxGF2bGZXLUuAM"
            />
            <div className="min-w-0">
              <h1 className="text-base sm:text-lg font-bold text-slate-900 leading-tight">Ledger</h1>
              <p className="text-xs text-slate-500 hidden sm:block">View and manage ledger transactions</p>
            </div>
          </div>
          <div className="flex items-center justify-end">
            <button 
              onClick={() => {
                // Reset filters
                setSelectedMonth(6);
                setSelectedYear(2026);
                setSelectedEventId('all');
                setSearchTerm('');
                setFilterType('all');
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50/50 transition-colors text-xs font-semibold cursor-pointer"
              title="Clear all filters"
            >
              <span className="material-symbols-outlined text-[16px]">restart_alt</span>
              <span>Reset</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-[1200px] mx-auto px-4 md:px-8 py-6">
        {/* Search & Dynamic Filters panel */}
        <section className="mb-8 bg-white border border-slate-200 p-5 rounded-2xl shadow-xs space-y-4">
          <div className="flex flex-col md:flex-row gap-3">
            {/* Search Input */}
            <div className="relative group flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 h-5 w-5" />
              <input
                type="text"
                placeholder="Search transactions..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full h-12 pl-12 pr-4 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all text-sm text-slate-800 placeholder-slate-400 font-medium"
              />
            </div>

            {/* Income/Expense chip filters */}
            <div className="flex gap-1.5 bg-slate-100 p-1.5 rounded-xl self-start md:self-auto">
              <button
                onClick={() => setFilterType('all')}
                className={`px-4 py-2 rounded-lg font-bold text-xs uppercase tracking-wider transition-all cursor-pointer ${
                  filterType === 'all'
                    ? 'bg-white text-indigo-700 shadow-xs'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setFilterType('income')}
                className={`px-4 py-2 rounded-lg font-bold text-xs uppercase tracking-wider transition-all cursor-pointer ${
                  filterType === 'income'
                    ? 'bg-white text-emerald-600 shadow-xs'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                Income
              </button>
              <button
                onClick={() => setFilterType('expense')}
                className={`px-4 py-2 rounded-lg font-bold text-xs uppercase tracking-wider transition-all cursor-pointer ${
                  filterType === 'expense'
                    ? 'bg-white text-rose-500 shadow-xs'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                Expenses
              </button>
            </div>
          </div>

          {/* Period and Event controls */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Month Period Selector */}
            <div className="relative flex items-center">
              <span className="material-symbols-outlined text-[18px] absolute left-3.5 text-slate-400 pointer-events-none">calendar_month</span>
              <select
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(Number(e.target.value))}
                className="w-full bg-white border border-slate-200 rounded-xl pl-10 pr-8 py-2.5 text-xs font-bold text-slate-700 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 cursor-pointer appearance-none hover:bg-slate-50 transition-colors"
              >
                <option value={0}>All Months</option>
                {MONTH_NAMES.map((name, idx) => (
                  <option key={idx} value={idx + 1}>
                    {name}
                  </option>
                ))}
              </select>
              <span className="material-symbols-outlined text-[18px] absolute right-3 text-slate-400 pointer-events-none font-bold">expand_more</span>
            </div>

            {/* Year Period Selector */}
            <div className="relative flex items-center">
              <span className="material-symbols-outlined text-[18px] absolute left-3.5 text-slate-400 pointer-events-none">schedule</span>
              <select
                value={selectedYear}
                onChange={(e) => setSelectedYear(Number(e.target.value))}
                className="w-full bg-white border border-slate-200 rounded-xl pl-10 pr-8 py-2.5 text-xs font-bold text-slate-700 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 cursor-pointer appearance-none hover:bg-slate-50 transition-colors"
              >
                <option value={0}>All Years</option>
                {[2024, 2025, 2026, 2027].map((yr) => (
                  <option key={yr} value={yr}>
                    {yr}
                  </option>
                ))}
              </select>
              <span className="material-symbols-outlined text-[18px] absolute right-3 text-slate-400 pointer-events-none font-bold">expand_more</span>
            </div>

            {/* Event Selector */}
            <div className="relative flex items-center">
              <span className="material-symbols-outlined text-[18px] absolute left-3.5 text-slate-400 pointer-events-none">layers</span>
              <select
                value={selectedEventId}
                onChange={(e) => setSelectedEventId(e.target.value)}
                className="w-full bg-white border border-slate-200 rounded-xl pl-10 pr-8 py-2.5 text-xs font-bold text-slate-700 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 cursor-pointer appearance-none hover:bg-slate-50 transition-colors truncate"
              >
                <option value="all">All Events</option>
                {filteredEventsForDropdown.map((evt) => (
                  <option key={evt.id} value={evt.id}>
                    {evt.name}
                  </option>
                ))}
              </select>
              <span className="material-symbols-outlined text-[18px] absolute right-3 text-slate-400 pointer-events-none font-bold">expand_more</span>
            </div>
          </div>
        </section>

        {/* Dynamic transaction groups output */}
        {Object.keys(txGroups).length === 0 ? (
          <div className="text-center py-16 text-slate-400 bg-white rounded-2xl border border-dashed border-slate-200 flex flex-col items-center justify-center">
            <span className="material-symbols-outlined text-[44px] text-slate-300 mb-3">receipt_long</span>
            <h3 className="text-sm font-bold text-slate-700 mb-1">No transactions found</h3>
            <p className="text-xs text-slate-400 max-w-xs mx-auto leading-relaxed">
              No results found matching your active filters. Try resetting the criteria.
            </p>
          </div>
        ) : (
          <div className="space-y-8 animate-fade-in">
            {Object.keys(txGroups).map((groupLabel) => (
              <section key={groupLabel}>
                <h2 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3.5 pl-1 font-sans">
                  {groupLabel}
                </h2>
                <div className="space-y-3">
                  {txGroups[groupLabel].map((tx) => (
                    <div
                      key={tx.id}
                      className="flex items-center justify-between p-4 bg-white border border-slate-200 rounded-2xl hover:shadow-xs transition-all group"
                    >
                      <div className="flex items-center gap-4 min-w-0 flex-1">
                        <div
                          className="w-12 h-12 rounded-full flex items-center justify-center transition-transform group-hover:scale-105 shrink-0"
                          style={{
                            backgroundColor: tx.type === 'income' ? 'rgba(16, 185, 129, 0.1)' : 'rgba(239, 68, 68, 0.08)'
                          }}
                        >
                          <span
                            className="material-symbols-outlined text-[20px]"
                            style={{ color: tx.type === 'income' ? '#10b981' : '#f43f5e' }}
                          >
                            {getCategoryIcon(tx.categoryId)}
                          </span>
                        </div>
                        <div className="min-w-0">
                          <h3 className="text-sm font-bold text-slate-800 truncate">{tx.title}</h3>
                          <p className="text-xs text-slate-400 mt-0.5 truncate">
                            {tx.date} • {tx.vendor || 'Personal'}
                            {tx.isRecurring && <span className="ml-1.5 bg-indigo-50 text-indigo-600 px-1.5 py-0.5 rounded text-[10px] uppercase tracking-wider font-bold">Auto</span>}
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-4 shrink-0 pl-3">
                        <div className="text-right">
                          <span
                            className={`font-mono text-sm font-bold ${
                              tx.type === 'income' ? 'text-emerald-600' : 'text-rose-600'
                            }`}
                          >
                            {tx.type === 'income' ? '+' : '-'}
                            {tx.currency === 'VND' ? '₫' : tx.currency === 'USD' ? '$' : tx.currency === 'SGD' ? 'S$' : tx.currency === 'EUR' ? '€' : '$'}
                            {tx.amount.toLocaleString('en-US', { minimumFractionDigits: (tx.currency || 'USD') === 'VND' ? 0 : 2, maximumFractionDigits: (tx.currency || 'USD') === 'VND' ? 0 : 2 })}
                          </span>
                        </div>

                        {/* Inline Edit & Delete controls */}
                        <div className="flex items-center gap-1">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setEditingTx(tx);
                            }}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50/50 transition-colors cursor-pointer"
                            title="Edit Transaction"
                          >
                            <span className="material-symbols-outlined text-[18px]">edit</span>
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setDeletingTxId(tx.id);
                            }}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50/55 transition-colors cursor-pointer"
                            title="Delete Transaction"
                          >
                            <span className="material-symbols-outlined text-[18px]">delete</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            ))}
          </div>
        )}
      </main>

      {/* EDIT MODAL DIALOG */}
      {editingTx && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-3xl p-6 shadow-2xl relative w-full max-w-md border border-slate-100 max-h-[90vh] overflow-y-auto">
            <h2 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
              <span className="material-symbols-outlined text-indigo-600">edit_note</span>
              Edit Ledger Transaction
            </h2>

            <form onSubmit={handleEditSubmit} className="space-y-4">
              {/* Title */}
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                  Transaction Title *
                </label>
                <input
                  type="text"
                  required
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  className="w-full h-11 px-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none text-sm text-slate-800 font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                {/* Amount */}
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                    Amount *
                  </label>
                  <input
                    type="number"
                    step="any"
                    required
                    min="0.01"
                    value={editAmount}
                    onChange={(e) => setEditAmount(Number(e.target.value))}
                    className="w-full h-11 px-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none text-sm font-mono text-slate-800 font-medium"
                  />
                </div>

                {/* Currency */}
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                    Currency
                  </label>
                  <select
                    value={editCurrency}
                    onChange={(e) => setEditCurrency(e.target.value)}
                    className="w-full h-11 px-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none text-sm text-slate-800 font-medium cursor-pointer"
                  >
                    <option value="USD">USD ($)</option>
                    <option value="VND">VND (₫)</option>
                    <option value="SGD">SGD (S$)</option>
                    <option value="EUR">EUR (€)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {/* Type */}
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                    Type
                  </label>
                  <select
                    value={editType}
                    onChange={(e) => setEditType(e.target.value as 'income' | 'expense')}
                    className="w-full h-11 px-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none text-sm text-slate-800 font-medium cursor-pointer"
                  >
                    <option value="expense">Expense</option>
                    <option value="income">Income</option>
                  </select>
                </div>

                {/* Date */}
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                    Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={editDate}
                    onChange={(e) => setEditDate(e.target.value)}
                    className="w-full h-11 px-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none text-sm text-slate-800 font-medium"
                  />
                </div>
              </div>

              {/* Category */}
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                  Category
                </label>
                <select
                  value={editCategoryId}
                  onChange={(e) => setEditCategoryId(e.target.value)}
                  className="w-full h-11 px-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none text-sm text-slate-800 font-medium cursor-pointer"
                >
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.type})
                    </option>
                  ))}
                </select>
              </div>

              {/* Mapped Event */}
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                  Associated Event Budget
                </label>
                <select
                  value={editEventId}
                  onChange={(e) => setEditEventId(e.target.value)}
                  className="w-full h-11 px-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none text-sm text-slate-800 font-medium cursor-pointer"
                >
                  <option value="">Generic / No Event</option>
                  {events.map((evt) => (
                    <option key={evt.id} value={evt.id}>
                      {evt.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Vendor & Note */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                    Payee / Vendor
                  </label>
                  <input
                    type="text"
                    value={editVendor}
                    onChange={(e) => setEditVendor(e.target.value)}
                    className="w-full h-11 px-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none text-sm text-slate-800 font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                    Note / Remark
                  </label>
                  <input
                    type="text"
                    value={editNote}
                    onChange={(e) => setEditNote(e.target.value)}
                    className="w-full h-11 px-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none text-sm text-slate-800 font-medium"
                  />
                </div>
              </div>

              {/* Recurring Switch */}
              <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <div>
                  <span className="text-xs font-bold text-slate-700 block">Recurring Transaction</span>
                  <p className="text-[10px] text-slate-400">Apply rules to repeat ledger schedule</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={editIsRecurring}
                    onChange={(e) => setEditIsRecurring(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-200 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                </label>
              </div>

              {editIsRecurring && (
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                    Frequency
                  </label>
                  <select
                    value={editFrequency}
                    onChange={(e) => setEditFrequency(e.target.value as 'weekly' | 'monthly' | 'yearly')}
                    className="w-full h-11 px-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none text-sm text-slate-800 font-medium cursor-pointer"
                  >
                    <option value="weekly">Weekly</option>
                    <option value="monthly">Monthly</option>
                    <option value="yearly">Yearly</option>
                  </select>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setEditingTx(null)}
                  className="flex-1 h-11 text-xs font-bold text-slate-500 border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 h-11 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  Apply Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CONFIRM DELETE DIALOG */}
      {deletingTxId && (
        <div className="fixed inset-0 z-55 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-3xl p-6 shadow-2xl w-full max-w-sm border border-slate-100 text-center">
            <div className="w-14 h-14 rounded-full bg-rose-50 flex items-center justify-center border border-rose-100 text-rose-500 mx-auto mb-4">
              <span className="material-symbols-outlined text-[28px]">delete_forever</span>
            </div>
            <h2 className="text-lg font-bold text-slate-800 mb-2">Delete Transaction?</h2>
            <p className="text-xs text-slate-400 leading-relaxed mb-6">
              Are you sure you want to delete this transaction from the ledger? This action cannot be undone and will automatically update associated event and category budgets.
            </p>

            <div className="flex gap-3">
              <button
                onClick={() => setDeletingTxId(null)}
                className="flex-1 h-11 text-xs font-bold text-slate-500 border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors cursor-pointer"
              >
                Go Back
              </button>
              <button
                onClick={handleDeleteConfirm}
                className="flex-1 h-11 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-xs transition-colors cursor-pointer"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Action FAB */}
      <button
        onClick={() => setScreen('LOG_TRANSACTION')}
        className="fixed bottom-24 right-6 w-14 h-14 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl shadow-xl hover:shadow-2xl active:scale-90 transition-all flex items-center justify-center z-50 md:hidden"
      >
        <span className="material-symbols-outlined text-3xl">add</span>
      </button>

      {/* Bottom Nav bar */}
      <nav className="fixed bottom-0 left-0 w-full z-50 flex justify-around items-center px-4 py-2 bg-white border-t border-slate-200 shadow-lg rounded-t-2xl md:hidden">
        <a
          onClick={() => setScreen('EVENT_OVERVIEW')}
          className="flex flex-col items-center justify-center text-slate-500 hover:text-indigo-600 transition-all scale-95 hover:scale-105 active:scale-90 cursor-pointer py-1.5"
        >
          <span className="material-symbols-outlined">dashboard</span>
          <span className="text-[10px] font-semibold uppercase tracking-wider mt-0.5">Overview</span>
        </a>

        <a
          onClick={() => setScreen('TRANSACTION_LEDGER')}
          className="flex flex-col items-center justify-center text-indigo-600 bg-indigo-50 rounded-xl px-4 py-1.5 transition-all duration-200 hover:scale-105 active:scale-95 font-bold cursor-pointer"
        >
          <span className="material-symbols-outlined" style={{ fontVariationSettings: "'FILL' 1" }}>
            receipt_long
          </span>
          <span className="text-[10px] font-bold uppercase tracking-wider mt-0.5">Ledger</span>
        </a>

        <a
          onClick={() => setScreen('EVENT_BUDGET_PLANNER')}
          className="flex flex-col items-center justify-center text-slate-500 hover:text-indigo-600 transition-all scale-95 hover:scale-105 active:scale-90 cursor-pointer py-1.5"
        >
          <span className="material-symbols-outlined">savings</span>
          <span className="text-[10px] font-semibold uppercase tracking-wider mt-0.5">Planner</span>
        </a>

        <a
          onClick={() => setScreen('LOG_TRANSACTION')}
          className="flex flex-col items-center justify-center text-slate-500 hover:text-indigo-600 transition-all scale-95 hover:scale-105 active:scale-90 cursor-pointer py-1.5"
        >
          <span className="material-symbols-outlined">add_circle</span>
          <span className="text-[10px] font-semibold uppercase tracking-wider mt-0.5">Quick Log</span>
        </a>
      </nav>
    </div>
  );
}
