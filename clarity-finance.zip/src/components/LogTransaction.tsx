import React, { useState, useEffect, useMemo } from 'react';
import { Event, Category, Transaction } from '../types';
import { ChevronDown, Calendar as CalendarIcon, Upload, ArrowLeft } from 'lucide-react';

function isDateInEventRange(txDateStr: string, dateRangeStr: string): boolean {
  if (!txDateStr) return true;
  const dateParts = txDateStr.split('-');
  if (dateParts.length !== 3) return true;
  const txYear = parseInt(dateParts[0], 10);
  const txMonth = parseInt(dateParts[1], 10) - 1; // 0-indexed
  const txDay = parseInt(dateParts[2], 10);

  const range = dateRangeStr.trim().toLowerCase();
  if (!range || range === 'ongoing') return true;

  const monthsMap: { [key: string]: number } = {
    jan: 0, january: 0,
    feb: 1, february: 1,
    mar: 2, march: 2,
    apr: 3, april: 3,
    may: 4,
    jun: 5, june: 5,
    jul: 6, july: 6,
    aug: 7, august: 7,
    sep: 8, september: 8,
    oct: 9, october: 9,
    nov: 10, november: 10,
    dec: 11, december: 11
  };

  function findMonth(str: string): number | null {
    for (const [key, val] of Object.entries(monthsMap)) {
      if (str.includes(key)) {
        return val;
      }
    }
    return null;
  }

  function findYear(str: string): number | null {
    const match = str.match(/\b(20\d{2})\b/);
    return match ? parseInt(match[1], 10) : null;
  }

  // Check if it's a multi-month range like "Jun 2026 - Jul 2026"
  if (range.includes('-')) {
    const parts = range.split('-').map(p => p.trim());
    if (parts.length === 2) {
      const m1 = findMonth(parts[0]);
      const y1 = findYear(parts[0]);
      const m2 = findMonth(parts[1]);
      const y2 = findYear(parts[1]);

      if (m1 !== null && y1 !== null && m2 !== null && y2 !== null) {
        const txVal = txYear * 12 + txMonth;
        const startVal = y1 * 12 + m1;
        const endVal = y2 * 12 + m2;
        return txVal >= startVal && txVal <= endVal;
      }
    }
  }

  // Single month/year or month day range
  const month = findMonth(range);
  const year = findYear(range);

  if (month === null && year === null) {
    // Cannot parse any year or month, fallback to true to prevent disappearance
    return true;
  }

  const numbers = range.match(/\d+/g) || [];
  const yearStr = year ? year.toString() : '';
  const dayNumbers = numbers.filter(num => num !== yearStr).map(n => parseInt(n, 10));

  if (year !== null && txYear !== year) return false;
  if (month !== null && txMonth !== month) return false;

  if (dayNumbers.length > 0) {
    if (dayNumbers.length === 1) {
      return txDay === dayNumbers[0];
    } else {
      // e.g. [18, 20]
      return txDay >= dayNumbers[0] && txDay <= dayNumbers[1];
    }
  }

  return true;
}

interface LogTransactionProps {
  events: Event[];
  categories: Category[];
  onSave: (newTx: Omit<Transaction, 'id'>) => void;
  setScreen: (screen: 'EVENT_OVERVIEW' | 'LOG_TRANSACTION' | 'TRANSACTION_LEDGER' | 'EVENT_BUDGET_PLANNER' | 'EVENT_BUDGET_DETAIL' | 'MANAGE_EVENTS' | 'MANAGE_CATEGORIES' | 'YEARLY_SUMMARY') => void;
}

export default function LogTransaction({
  events,
  categories,
  onSave,
  setScreen
}: LogTransactionProps) {
  const [amount, setAmount] = useState<string>('0.00');
  const [txType, setTxType] = useState<'expense' | 'income'>('expense');
  const [title, setTitle] = useState('');
  const [selectedEventId, setSelectedEventId] = useState(events[0]?.id || '');
  const [currency, setCurrency] = useState('VND');
  const [vendor, setVendor] = useState('');
  const [selectedCatId, setSelectedCatId] = useState('');
  const [date, setDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [isRecurring, setIsRecurring] = useState(false);
  const [frequency, setFrequency] = useState<'weekly' | 'monthly' | 'yearly'>('monthly');
  const [note, setNote] = useState('');

  // Filter events matching the transaction date
  const filteredEventsForDate = useMemo(() => {
    return events.filter((evt) => isDateInEventRange(date, evt.dateRange));
  }, [date, events]);

  // Keep selectedEventId valid and bound to the filtered list
  useEffect(() => {
    if (filteredEventsForDate.length > 0) {
      if (!filteredEventsForDate.some((evt) => evt.id === selectedEventId)) {
        setSelectedEventId(filteredEventsForDate[0].id);
      }
    } else {
      setSelectedEventId('');
    }
  }, [date, events, selectedEventId, filteredEventsForDate]);

  // Auto-switch selected category to the first available of matching type if invalid
  useEffect(() => {
    const validCats = categories.filter((cat) => {
      if (txType === 'expense') {
        return !cat.type || cat.type === 'expense';
      } else {
        return cat.type === 'income';
      }
    });

    if (validCats.length > 0) {
      if (!validCats.some((c) => c.id === selectedCatId)) {
        setSelectedCatId(validCats[0].id);
      }
    }
  }, [txType, categories, selectedCatId]);

  // Keypad actions
  const handleKeyClick = (val: string) => {
    if (val === 'back') {
      if (amount.length <= 1) {
        setAmount('0.00');
      } else {
        setAmount(amount.slice(0, -1));
      }
    } else {
      if (amount === '0.00') {
        if (val === '.') {
          setAmount('0.');
        } else {
          setAmount(val);
        }
      } else {
        // Prevent multiple decimals
        if (val === '.' && amount.includes('.')) return;
        // Limit to 2 decimals
        if (amount.includes('.')) {
          const parts = amount.split('.');
          if (parts[1].length >= 2) return;
        }
        setAmount(amount + val);
      }
    }
  };

  const handleSave = () => {
    const numericAmount = parseFloat(amount) || 0;
    onSave({
      title: title.trim() || 'Untitled Transaction',
      amount: numericAmount,
      type: txType,
      date,
      categoryId: selectedCatId,
      eventId: selectedEventId,
      isRecurring,
      frequency: isRecurring ? frequency : undefined,
      note: note.trim(),
      vendor: vendor.trim() || undefined,
      currency
    });
    setScreen('TRANSACTION_LEDGER');
  };

  const getCategoryIconSymbol = (cat: Category) => {
    if (cat.id === 'cat-housing') return 'home';
    if (cat.id === 'cat-groceries') return 'local_grocery_store';
    if (cat.id === 'cat-transport') return 'commute';
    if (cat.id === 'cat-dining') return 'restaurant';
    if (cat.id === 'cat-entertainment') return 'movie';
    if (cat.id === 'cat-utilities') return 'bolt';
    if (cat.id === 'cat-health') return 'medical_services';

    switch (cat.icon) {
      case 'Home': return 'home';
      case 'ShoppingCart': return 'shopping_cart';
      case 'Car': return 'directions_car';
      case 'Utensils': return 'restaurant';
      case 'Film': return 'movie';
      case 'Zap': return 'bolt';
      case 'HeartPulse': return 'medical_services';
      case 'Checkroom': return 'checkroom';
      case 'Payments': return 'payments';
      case 'ShowChart': return 'show_chart';
      case 'Savings': return 'savings';
      case 'Book': return 'menu_book';
      case 'Flight': return 'flight';
      case 'Work': return 'work';
      case 'Pets': return 'pets';
      case 'Gift': return 'card_giftcard';
      case 'Music': return 'music_note';
      case 'Coffee': return 'local_cafe';
      case 'MoreHorizontal': return 'more_horiz';
      default: return 'category';
    }
  };

  const filteredCategories = categories.filter((cat) => {
    if (txType === 'expense') {
      return !cat.type || cat.type === 'expense';
    } else {
      return cat.type === 'income';
    }
  });

  return (
    <div className="bg-slate-50 text-slate-900 min-h-screen pb-24">
      {/* Top AppBar */}
      <header className="bg-white border-b border-slate-200 w-full sticky top-0 z-40 shadow-sm">
        <div className="flex justify-between items-center px-4 md:px-12 h-16 w-full max-w-7xl mx-auto">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setScreen('EVENT_OVERVIEW')}
              className="text-slate-500 hover:text-indigo-600 transition-colors p-2 rounded-full cursor-pointer hover:bg-slate-50"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
            <div>
              <h1 className="text-base font-extrabold text-slate-900 leading-tight">Quick Log</h1>
              <p className="text-xs text-slate-500">Record a new transaction instantly</p>
            </div>
          </div>
          <button className="text-slate-500 hover:bg-slate-100 p-2 rounded-full transition-colors cursor-pointer">
            <span className="material-symbols-outlined text-[24px]">calendar_month</span>
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 md:px-12 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Left Column: Keypad & Amount Column */}
          <div className="lg:col-span-5 flex flex-col justify-between gap-6 bg-white p-6 md:p-8 rounded-3xl border border-slate-200/80 shadow-md">
            {/* Amount display card */}
            <div className="bg-slate-50/70 p-6 rounded-2xl border border-slate-200/80 text-center">
              <span className="text-[11px] font-bold tracking-widest text-slate-400 block mb-2 uppercase">Amount</span>
              <div className="flex items-center justify-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const list = ['VND', 'USD', 'SGD', 'EUR'];
                    const currentIdx = list.indexOf(currency);
                    const nextIdx = (currentIdx + 1) % list.length;
                    setCurrency(list[nextIdx]);
                  }}
                  className="text-2xl font-black text-indigo-500 hover:text-indigo-700 transition-all scale-105 active:scale-95 px-3 py-1 rounded-xl hover:bg-white/85 cursor-pointer shadow-sm border border-slate-200/50"
                  title="Click to change currency"
                >
                  {currency === 'VND' ? '₫' : currency === 'USD' ? '$' : currency === 'SGD' ? 'S$' : '€'}
                </button>
                <span className="text-4xl md:text-5xl font-black text-indigo-600 tracking-tight" id="amount-display">{amount}</span>
              </div>
            </div>

            {/* Spent (Expense) vs Income toggler */}
            <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200/60">
              <button
                type="button"
                onClick={() => setTxType('expense')}
                className={`flex-1 py-3 rounded-lg font-bold text-xs uppercase tracking-wider transition-all duration-200 text-center cursor-pointer ${
                  txType === 'expense'
                    ? 'bg-rose-600 text-white shadow-md'
                    : 'text-slate-500 hover:text-rose-600'
                }`}
              >
                Spent
              </button>
              <button
                type="button"
                onClick={() => setTxType('income')}
                className={`flex-1 py-3 rounded-lg font-bold text-xs uppercase tracking-wider transition-all duration-200 text-center cursor-pointer ${
                  txType === 'income'
                    ? 'bg-emerald-600 text-white shadow-md'
                    : 'text-slate-500 hover:text-emerald-600'
                }`}
              >
                Income
              </button>
            </div>

            {/* Numeric Keypad layout */}
            <div className="grid grid-cols-3 gap-2.5 p-2 bg-slate-50/70 rounded-2xl border border-slate-200/60">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
                <button
                  key={num}
                  type="button"
                  onClick={() => handleKeyClick(num)}
                  className="h-12 md:h-14 flex items-center justify-center bg-white rounded-xl font-extrabold text-base md:text-lg text-slate-800 shadow-sm border border-slate-200/30 hover:bg-indigo-50 active:scale-95 transition-all text-center cursor-pointer"
                >
                  {num}
                </button>
              ))}
              <button
                type="button"
                onClick={() => handleKeyClick('.')}
                className="h-12 md:h-14 flex items-center justify-center bg-white rounded-xl font-extrabold text-base md:text-lg text-slate-800 shadow-sm border border-slate-200/30 hover:bg-indigo-50 active:scale-95 transition-all text-center cursor-pointer"
              >
                .
              </button>
              <button
                type="button"
                onClick={() => handleKeyClick('0')}
                className="h-12 md:h-14 flex items-center justify-center bg-white rounded-xl font-extrabold text-base md:text-lg text-slate-800 shadow-sm border border-slate-200/30 hover:bg-indigo-50 active:scale-95 transition-all text-center cursor-pointer"
              >
                0
              </button>
              <button
                type="button"
                onClick={() => handleKeyClick('back')}
                className="h-12 md:h-14 flex items-center justify-center bg-white rounded-xl font-semibold text-slate-500 shadow-sm border border-slate-200/30 hover:bg-rose-50 active:scale-95 transition-all cursor-pointer"
              >
                <span className="material-symbols-outlined text-[20px]">backspace</span>
              </button>
            </div>
          </div>

          {/* Right Column: Form details & integrated category selector */}
          <div className="lg:col-span-7 flex flex-col justify-between gap-6 bg-white p-6 md:p-8 rounded-3xl border border-slate-200/80 shadow-md">
            {/* Input fields grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Title Input */}
              <div className="flex flex-col gap-1">
                <label className="text-[10px] font-bold tracking-wider text-slate-500 uppercase">Title</label>
                <input
                  type="text"
                  placeholder="e.g. Lunch"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full h-11 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-850 text-slate-800 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 focus:outline-none transition-all outline-none"
                />
              </div>

              {/* Event Select */}
              <div className="flex flex-col gap-1">
                <label className="text-[10px] font-bold tracking-wider text-slate-500 uppercase">Event (Matches Date)</label>
                <div className="relative">
                  <select
                    value={selectedEventId}
                    onChange={(e) => setSelectedEventId(e.target.value)}
                    className="w-full h-11 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 focus:outline-none transition-all outline-none appearance-none cursor-pointer pr-10"
                  >
                    <option value="">Select Event</option>
                    {filteredEventsForDate.map((evt) => (
                      <option key={evt.id} value={evt.id}>
                        {evt.name} ({evt.dateRange})
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none h-4 w-4" />
                </div>
              </div>

              {/* Transaction Date */}
              <div className="flex flex-col gap-1">
                <label className="text-[10px] font-bold tracking-wider text-slate-500 uppercase">Transaction Date</label>
                <div className="relative">
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full h-11 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-none transition-all pr-10 cursor-pointer"
                  />
                  <CalendarIcon className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none h-4 w-4" />
                </div>
              </div>

              {/* Vendor Input */}
              <div className="flex flex-col gap-1">
                <label className="text-[10px] font-bold tracking-wider text-slate-500 uppercase">Vendor</label>
                <input
                  type="text"
                  placeholder="Enter vendor name"
                  value={vendor}
                  onChange={(e) => setVendor(e.target.value)}
                  className="w-full h-11 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-850 text-slate-800 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 focus:outline-none transition-all outline-none"
                />
              </div>

              {/* Note Input */}
              <div className="flex flex-col gap-1">
                <label className="text-[10px] font-bold tracking-wider text-slate-500 uppercase">Note</label>
                <input
                  type="text"
                  placeholder="Add a description..."
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  className="w-full h-11 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-850 text-slate-800 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 focus:outline-none transition-all outline-none"
                />
              </div>

              {/* Recurring Switch */}
              <div className="flex flex-col gap-1">
                <label className="text-[10px] font-bold tracking-wider text-slate-500 uppercase">Recurring Settings</label>
                <div className="flex items-center gap-2 h-11 px-3 bg-slate-50 border border-slate-200 rounded-xl">
                  <input
                    type="checkbox"
                    id="recur-check"
                    checked={isRecurring}
                    onChange={(e) => setIsRecurring(e.target.checked)}
                    className="h-4 w-4 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300 cursor-pointer"
                  />
                  <label htmlFor="recur-check" className="text-xs font-semibold text-slate-600 cursor-pointer select-none">
                    Recurring
                  </label>
                  {isRecurring && (
                    <select
                      value={frequency}
                      onChange={(e) => setFrequency(e.target.value as any)}
                      className="ml-auto bg-transparent border-none text-xs font-bold text-indigo-600 focus:ring-0 cursor-pointer outline-none py-0 pr-8"
                    >
                      <option value="weekly">Weekly</option>
                      <option value="monthly">Monthly</option>
                      <option value="yearly">Yearly</option>
                    </select>
                  )}
                </div>
              </div>
            </div>

            {/* Custom Interactive Category Grid with filtered ones */}
            <div className="flex flex-col gap-2 pt-2 border-t border-slate-100">
              <span className="text-[10px] font-bold tracking-wider text-slate-400 uppercase block">Select Category</span>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5 max-h-[160px] overflow-y-auto p-1 pr-2">
                {filteredCategories.map((cat) => {
                  const isSelected = selectedCatId === cat.id;
                  return (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setSelectedCatId(cat.id)}
                      className={`flex items-center gap-2 px-3 py-2 rounded-xl border-2 transition-all cursor-pointer text-left ${
                        isSelected
                          ? 'bg-indigo-50/60 border-indigo-600 text-indigo-700 font-bold'
                          : 'border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-500'
                      }`}
                    >
                      <div className="w-7 h-7 rounded-full bg-white flex items-center justify-center shrink-0 shadow-sm border border-slate-100">
                        <span className="material-symbols-outlined text-sm" style={{ color: cat.color }}>
                          {getCategoryIconSymbol(cat)}
                        </span>
                      </div>
                      <span className="text-xs truncate font-semibold ml-1">{cat.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Action Buttons Row */}
            <div className="flex gap-4 items-center pt-3 border-t border-slate-100">
              <button
                type="button"
                className="flex-1 h-12 bg-slate-50 hover:bg-slate-100 rounded-xl border border-dashed border-slate-300 flex items-center justify-center gap-1.5 text-slate-500 transition-all text-xs font-bold cursor-pointer"
              >
                <Upload className="h-4 w-4 text-slate-400" />
                <span>Upload</span>
              </button>

              <button
                id="save-btn"
                onClick={handleSave}
                className="flex-[2.5] flex h-12 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold hover:shadow-md active:scale-95 transition-all items-center justify-center gap-1.5 text-xs uppercase tracking-wider text-center cursor-pointer"
              >
                <span>Save Transaction</span>
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* Nav Spec Footer Actions */}
      <footer className="fixed bottom-0 left-0 w-full z-50 flex justify-around items-center px-4 py-2.5 bg-white border-t border-slate-200 shadow-lg rounded-t-3xl md:hidden">
        <button
          onClick={() => setScreen('EVENT_OVERVIEW')}
          className="flex flex-col items-center justify-center text-slate-500 hover:text-indigo-600 transition-colors py-1 cursor-pointer"
        >
          <span className="material-symbols-outlined text-[22px]">dashboard</span>
          <span className="text-[10px] font-semibold uppercase tracking-wider mt-0.5">Overview</span>
        </button>

        <button
          onClick={() => setScreen('TRANSACTION_LEDGER')}
          className="flex flex-col items-center justify-center text-slate-500 hover:text-indigo-600 transition-colors py-1 cursor-pointer"
        >
          <span className="material-symbols-outlined text-[22px]">receipt_long</span>
          <span className="text-[10px] font-semibold uppercase tracking-wider mt-0.5">Ledger</span>
        </button>

        <button
          onClick={() => setScreen('EVENT_BUDGET_PLANNER')}
          className="flex flex-col items-center justify-center text-slate-500 hover:text-indigo-600 transition-colors py-1 cursor-pointer"
        >
          <span className="material-symbols-outlined text-[22px]">savings</span>
          <span className="text-[10px] font-semibold uppercase tracking-wider mt-0.5">Planner</span>
        </button>

        <button
          onClick={() => setScreen('LOG_TRANSACTION')}
          className="flex flex-col items-center justify-center text-indigo-600 bg-indigo-50 rounded-xl px-4 py-1 transition-all duration-200 hover:scale-105 active:scale-95 font-bold cursor-pointer"
        >
          <span className="material-symbols-outlined text-[20px]">add_circle</span>
          <span className="text-[10px] font-bold uppercase tracking-wider mt-0.5">Quick Log</span>
        </button>
      </footer>
    </div>
  );
}
