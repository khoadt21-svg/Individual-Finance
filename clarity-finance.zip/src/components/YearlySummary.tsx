import React, { useState } from 'react';
import { Event } from '../types';
import { Landmark, TrendingUp, TrendingDown, Calendar, Check, AlertCircle } from 'lucide-react';

interface YearlySummaryProps {
  events: Event[];
  setScreen: (screen: 'EVENT_OVERVIEW' | 'LOG_TRANSACTION' | 'TRANSACTION_LEDGER' | 'EVENT_BUDGET_PLANNER' | 'EVENT_BUDGET_DETAIL' | 'MANAGE_EVENTS' | 'MANAGE_CATEGORIES' | 'YEARLY_SUMMARY') => void;
  onMenuClick?: () => void;
}

export default function YearlySummary({
  events,
  setScreen,
  onMenuClick
}: YearlySummaryProps) {
  const [selectedYear, setSelectedYear] = useState<string>('2026');
  const [selectedMonth, setSelectedMonth] = useState<string | null>(null);

  const monthsList = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  // Status computation for three states: Done, In Process, Not Yet
  // Uses June 2026 as the timeline context.
  const getStatusForMonth = (yearStr: string, monthIndex: number) => {
    const currentYear = 2026;
    const currentMonthIndex = 5; // June (0-indexed)
    const year = parseInt(yearStr);

    if (year < currentYear) {
      return 'Done';
    } else if (year > currentYear) {
      return 'Not Yet';
    } else {
      if (monthIndex < currentMonthIndex) {
        return 'Done';
      } else if (monthIndex === currentMonthIndex) {
        return 'In Process';
      } else {
        return 'Not Yet';
      }
    }
  };

  const getStatusBadgeStyle = (status: 'Done' | 'In Process' | 'Not Yet') => {
    switch (status) {
      case 'Done':
        return 'bg-emerald-50 text-emerald-700 border border-emerald-150';
      case 'In Process':
        return 'bg-amber-50 text-amber-700 border border-amber-200 animate-pulse font-bold';
      case 'Not Yet':
        return 'bg-slate-100 text-slate-400 border border-slate-200/60';
      default:
        return 'bg-slate-50 text-slate-500';
    }
  };

  // Map any Event to its month and year based on range / description
  const parseEventTiming = (evt: Event): { monthName: string; yearStr: string } | null => {
    const range = (evt.dateRange || '').toLowerCase();
    
    // 1. Check Year (e.g. "2024", "2025", "2026")
    let yearStr = '2026';
    const yearMatch = range.match(/\b(202\d)\b/);
    if (yearMatch) {
      yearStr = yearMatch[1];
    }

    // 2. Check Month
    const matchedMonth = monthsList.find(m => {
      const short = m.toLowerCase().slice(0, 3);
      return range.includes(m.toLowerCase()) || range.includes(short);
    });

    if (matchedMonth) {
      return { monthName: matchedMonth, yearStr };
    }

    // Fallbacks
    if (evt.id === 'evt-house-doc') {
      return { monthName: 'June', yearStr: '2026' };
    }

    return null;
  };

  // Dynamically calculate the roll-over income and savings month-by-month of a year.
  // "total income is sum of all income events of that month and savings of previous month."
  // "total spent is sum of all spent events of that month."
  const getComputedMonthlyDetails = (year: string) => {
    const computed: Array<{
      month: string;
      actualIncome: number;
      spent: number;
      savings: number;
      events: Event[];
    }> = [];

    monthsList.forEach((monthName, idx) => {
      // Find all events belonging to this month and year
      const matchingEvents = events.filter(evt => {
        const timing = parseEventTiming(evt);
        return timing && timing.monthName === monthName && timing.yearStr === year;
      });

      const isFuture = getStatusForMonth(year, idx) === 'Not Yet';

      // Sum income events: event.type === 'income'
      const incomeEvents = matchingEvents.filter(evt => evt.type === 'income');
      const baseIncome = incomeEvents.reduce((sum, evt) => sum + (evt.budget || 0), 0);

      // Sum spent events: event.type !== 'income' (spent events are of expense type, or not marked as income)
      const spentEvents = matchingEvents.filter(evt => evt.type !== 'income');
      const spentAmount = spentEvents.reduce((sum, evt) => {
        const val = isFuture ? (evt.budget || 0) : (evt.spent || 0);
        return sum + val;
      }, 0);

      // Savings rolling forward from previous month
      const prevSavings = idx === 0 ? 0 : computed[idx - 1].savings;

      // Actual income of this month is this month's base income + previous month's rolling savings
      const actualIncome = baseIncome + prevSavings;

      // Savings of this month is actual rolling income minus spent
      const savings = actualIncome - spentAmount;

      computed.push({
        month: monthName,
        actualIncome,
        spent: spentAmount,
        savings,
        events: matchingEvents
      });
    });

    return computed;
  };

  // Dynamically compute comparisonData for raw records across the years using our dynamic events calculations!
  const comparisonData = ['2026', '2025', '2024'].map(year => {
    const months = getComputedMonthlyDetails(year);
    let yearTotalSpent = 0;
    months.forEach(m => {
      yearTotalSpent += m.spent;
    });

    // Sum of base income events (not accumulated rolling income)
    let yearTotalBaseIncome = 0;
    events.forEach(evt => {
      const timing = parseEventTiming(evt);
      if (timing && timing.yearStr === year && evt.type === 'income') {
        yearTotalBaseIncome += (evt.budget || 0);
      }
    });

    const retainedSavings = yearTotalBaseIncome - yearTotalSpent;
    const spentRatio = yearTotalBaseIncome > 0 ? Math.round((yearTotalSpent / yearTotalBaseIncome) * 100) : 0;

    // Year progress status
    let status: 'Done' | 'In Process' | 'Not Yet' = 'Done';
    if (year === '2026') {
      status = 'In Process';
    } else if (parseInt(year) > 2026) {
      status = 'Not Yet';
    }

    return {
      year,
      totalIncome: yearTotalBaseIncome,
      totalSpent: yearTotalSpent,
      retainedSavings,
      spentRatio,
      status
    };
  });

  return (
    <div className="bg-slate-50 text-slate-900 min-h-screen pb-32">
      {/* TopAppBar */}
      <header className="bg-white border-b border-slate-200 w-full sticky top-0 z-40">
        <div className="flex flex-col sm:flex-row justify-between items-stretch sm:items-center px-4 md:px-8 py-3 sm:py-0 min-h-[5rem] sm:h-20 gap-3 w-full max-w-[1200px] mx-auto">
          <div className="flex items-center gap-2 md:gap-3">
            {onMenuClick && (
              <button
                onClick={onMenuClick}
                className="md:hidden text-slate-500 hover:bg-slate-100 p-2 rounded-full cursor-pointer flex items-center justify-center -ml-1 mr-1 shrink-0"
                aria-label="Open navigation menu"
              >
                <span className="material-symbols-outlined text-[24px]">menu</span>
              </button>
            )}
            <h1 className="text-base sm:text-lg font-bold text-slate-900 font-sans leading-tight">Yearly Summary</h1>
          </div>
          <div className="flex items-center justify-end shrink-0">
            <button className="text-slate-500 hover:bg-slate-100 p-2 rounded-full transition-colors cursor-pointer">
              <span className="material-symbols-outlined text-[22px]">calendar_month</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-[1200px] mx-auto px-4 md:px-8 py-6 font-sans">
        {/* Banner with view categories button */}
        <section className="mb-8">
          <div className="bg-gradient-to-br from-indigo-600 to-indigo-700 rounded-3xl p-6 md:p-8 text-white flex flex-col md:flex-row justify-between items-center gap-6 shadow-md relative overflow-hidden border border-indigo-600">
            <div className="relative z-10 max-w-xl text-left">
              <span className="text-xs font-bold tracking-widest uppercase opacity-85 block mb-1">ANNUAL FINANCIAL SCOREBOARD</span>
              <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight text-white leading-tight">Year-over-Year Analysis</h2>
              <p className="text-sm mt-2 leading-relaxed opacity-95 font-medium">
                Review budgeting effectiveness, actual spending indexes, and high-yield savings progress across multiple fiscal cycles.
              </p>
            </div>
            {/* VIEW DASHBOARD button */}
            <button
              onClick={() => setScreen('EVENT_OVERVIEW')}
              className="bg-white text-indigo-600 hover:bg-indigo-50 px-6 py-3 rounded-full font-bold text-xs tracking-wider uppercase shadow-md transition-all whitespace-nowrap z-10 hover:scale-105 active:scale-95 cursor-pointer"
            >
              VIEW DASHBOARD
            </button>
            <div className="absolute -left-12 -top-12 w-48 h-48 bg-white/5 rounded-full blur-2xl"></div>
          </div>
        </section>

        {/* Dynamic Comparison Matrix Card Table */}
        <section className="mb-8 font-sans">
          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
            <div className="p-5 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-800">Historical Fiscal Comparison</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 font-bold text-[10px] tracking-wider text-slate-400 opacity-80 uppercase">
                    <th className="p-4 pl-6 font-bold">FY Cycle</th>
                    <th className="p-4 font-bold text-right">Total Income</th>
                    <th className="p-4 font-bold text-right">Total Spent</th>
                    <th className="p-4 font-bold text-right">Retained Savings</th>
                    <th className="p-4 font-bold text-center">Spent Ratio</th>
                    <th className="p-4 pr-6 font-bold text-center">Progress Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-semibold text-sm text-slate-700">
                  {comparisonData.map((row) => {
                    const isSelected = selectedYear === row.year;
                    const spentRatioColor = row.spentRatio > 100 ? 'text-rose-600 font-bold' : 'text-indigo-600 font-bold';
                    return (
                      <tr 
                        key={row.year} 
                        onClick={() => setSelectedYear(row.year)}
                        className={`transition-all cursor-pointer group hover:bg-indigo-50/30 ${
                          isSelected ? 'bg-indigo-50/50 border-l-4 border-indigo-600' : ''
                        }`}
                        title="Click to view monthly details breakdown"
                      >
                        {/* FY Cycle */}
                        <td className="p-4 pl-6 font-extrabold text-indigo-600">
                          <div className="flex items-center gap-2">
                            <span className={`w-2 h-2 rounded-full ${isSelected ? 'bg-indigo-600 animate-pulse' : 'bg-transparent'}`} />
                            <span className={isSelected ? 'text-indigo-805 font-black text-base' : 'text-indigo-600'}>
                              {row.year}
                            </span>
                          </div>
                        </td>

                        {/* Total Income */}
                        <td className="p-4 text-right font-mono font-bold text-slate-800">
                          ${row.totalIncome.toLocaleString()}
                        </td>

                        {/* Total Spent */}
                        <td className="p-4 text-right font-mono font-bold text-slate-700">
                          ${row.totalSpent.toLocaleString()}
                        </td>

                        {/* Retained Savings */}
                        <td className={`p-4 text-right font-mono font-extrabold ${row.retainedSavings >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                          {row.retainedSavings >= 0 ? `+$${row.retainedSavings.toLocaleString()}` : `-$${Math.abs(row.retainedSavings).toLocaleString()}`}
                        </td>

                        {/* Spent Ratio */}
                        <td className="p-4 text-center">
                          <span className={`inline-block font-mono text-xs font-bold px-2 py-1 rounded bg-slate-50 border border-slate-100 ${spentRatioColor}`}>
                            {row.spentRatio}%
                          </span>
                        </td>

                        {/* Progress Status */}
                        <td className="p-4 pr-6 text-center text-xs">
                          <div className="flex items-center justify-center gap-3">
                            <span className={`inline-block px-3 py-1 rounded-full font-extrabold uppercase tracking-widest text-[9px] ${getStatusBadgeStyle(row.status)}`}>
                              {row.status}
                            </span>
                            <span className={`text-[9px] font-bold uppercase py-1 px-2.5 rounded-md transition-all ${
                              isSelected ? 'bg-indigo-600 text-white shadow-sm' : 'bg-slate-100 text-slate-400 group-hover:bg-slate-200 group-hover:text-slate-700'
                            }`}>
                              {isSelected ? 'Selected' : 'View Detail'}
                            </span>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </section>

        {/* Dynamic 12-Month Detailed Timeline View */}
        <section className="mb-10 font-sans animate-fade-in" id="monthly-drilldown">
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-indigo-50 pb-5 mb-6">
              <div>
                <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest block mb-1">
                  12-MONTH FISCAL TRACK
                </span>
                <h3 className="text-lg font-black text-slate-800 flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-indigo-600" />
                  Monthly Timeline Analysis — {selectedYear}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Chronological breakdown showing budgets, spent amounts, and savings yields from January to December.
                </p>
              </div>
              <div className="flex items-center gap-2 self-start sm:self-center bg-indigo-50/60 px-3 py-1.5 rounded-full border border-indigo-100">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                <span className="text-xs font-bold text-indigo-700">Year {selectedYear} Active Drilldown</span>
              </div>
            </div>

            {/* Months Detailed Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 font-bold text-[10px] tracking-wider text-slate-400 opacity-80 uppercase">
                    <th className="p-4 pl-6 font-bold">Month</th>
                    <th className="p-4 font-bold text-right">Total Income</th>
                    <th className="p-4 font-bold text-right">Total Spent</th>
                    <th className="p-4 font-bold text-right">Retained Savings</th>
                    <th className="p-4 font-bold text-center">Spent Ratio</th>
                    <th className="p-4 pr-6 font-bold text-center">Progress Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-semibold text-sm text-slate-700">
                  {getComputedMonthlyDetails(selectedYear).map((m, index) => {
                    const percentSpent = m.actualIncome > 0 ? Math.round((m.spent / m.actualIncome) * 100) : 0;
                    const isOverSpent = m.spent > m.actualIncome;
                    const statusColorClass = isOverSpent ? 'bg-rose-500' : 'bg-indigo-600';
                    const textColorClass = m.savings >= 0 ? 'text-emerald-600 font-bold' : 'text-rose-600 font-bold';
                    const monthStatus = getStatusForMonth(selectedYear, index);
                    const isSelected = selectedMonth === m.month;

                    return (
                      <React.Fragment key={m.month}>
                        <tr 
                          onClick={() => setSelectedMonth(isSelected ? null : m.month)}
                          className={`hover:bg-indigo-50/15 active:bg-indigo-50/35 cursor-pointer transition-colors ${
                            isSelected ? 'bg-indigo-50/20' : ''
                          }`}
                          title="Click to view detailed events for this month"
                        >
                          {/* Month Info */}
                          <td className="p-4 pl-6 font-extrabold text-slate-850">
                            <div className="flex items-center gap-3">
                              <span className="text-xs text-slate-300 font-mono font-bold">
                                M{(index + 1).toString().padStart(2, '0')}
                              </span>
                              <span className="text-sm font-extrabold text-slate-800 flex items-center gap-1.5">
                                {m.month}
                                <span className={`text-[9px] font-bold text-indigo-500 uppercase transition-opacity ${
                                  isSelected ? 'opacity-100' : 'opacity-40 hover:opacity-100'
                                }`}>
                                  {isSelected ? '▲ close' : '▼ expand'}
                                </span>
                              </span>
                            </div>
                          </td>

                          {/* Total Income */}
                          <td className="p-4 text-right font-mono font-bold text-indigo-700">
                            ${m.actualIncome.toLocaleString()}
                          </td>

                          {/* Total Spent */}
                          <td className="p-4 text-right font-mono font-bold text-slate-700">
                            ${m.spent.toLocaleString()}
                          </td>

                          {/* savings */}
                          <td className={`p-4 text-right font-mono font-extrabold ${textColorClass}`}>
                            {m.savings >= 0 ? `+$${m.savings.toLocaleString()}` : `-$${Math.abs(m.savings).toLocaleString()}`}
                          </td>

                          {/* Spent vs Income index with micro progress bar */}
                          <td className="p-4 min-w-[150px]">
                            <div className="flex flex-col gap-1 max-w-[140px] mx-auto font-sans">
                              <div className="flex justify-between items-center text-[10px] text-slate-400 font-semibold">
                                <span>Spent Ratio</span>
                                <span className={`font-mono font-bold ${isOverSpent ? 'text-rose-600' : 'text-indigo-600'}`}>
                                  {percentSpent}%
                                </span>
                              </div>
                              <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                                <div 
                                  className={`h-full rounded-full transition-all duration-300 ${statusColorClass}`}
                                  style={{ width: `${Math.min(percentSpent, 100)}%` }}
                                ></div>
                              </div>
                            </div>
                          </td>

                          {/* Live status badge: Done, In Process, Not Yet */}
                          <td className="p-4 pr-6 text-center text-xs">
                            <span className={`inline-block px-3 py-1 rounded-full font-extrabold uppercase tracking-widest text-[9px] ${getStatusBadgeStyle(monthStatus)}`}>
                              {monthStatus}
                            </span>
                          </td>
                        </tr>

                        {/* Collapsible Month Details */}
                        {isSelected && (
                          <tr className="bg-slate-50/40">
                            <td colSpan={6} className="p-0 border-b border-indigo-105">
                              <div className="p-6 font-sans">
                                <div className="flex justify-between items-center mb-4 border-b border-slate-100 pb-3">
                                  <div>
                                    <h4 className="text-xs font-black text-indigo-700 uppercase tracking-widest text-left">
                                      Monthly Events Drilldown — {m.month} {selectedYear}
                                    </h4>
                                    <p className="text-[11px] text-slate-500 font-medium mt-0.5 text-left">
                                      Detailed view of financial ledger events occurring during this month.
                                    </p>
                                  </div>
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setScreen('MANAGE_EVENTS');
                                    }}
                                    className="text-[10px] font-black text-indigo-650 text-indigo-650 hover:text-indigo-700 border border-indigo-200 bg-white hover:bg-indigo-50 px-3 py-1.5 rounded-xl transition-all uppercase tracking-wider cursor-pointer"
                                  >
                                    Manage Events
                                  </button>
                                </div>

                                {m.events.length === 0 ? (
                                  <div className="bg-white rounded-2xl border border-slate-200 p-6 text-center max-w-lg mx-auto shadow-sm">
                                    <Calendar className="w-8 h-8 text-indigo-200 mx-auto mb-2" />
                                    <p className="text-xs font-bold text-slate-705 text-slate-700">No events found in {m.month} {selectedYear}</p>
                                    <p className="text-[11px] text-slate-400 mt-1">
                                      Add monthly salaries, business payouts, or custom items inside Managed Events.
                                    </p>
                                  </div>
                                ) : (
                                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                    {m.events.map((evt) => {
                                      const isIncome = evt.type === 'income';
                                      return (
                                        <div 
                                          key={evt.id}
                                          className="bg-white border border-slate-205 border-slate-200 p-4 rounded-2xl shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow text-left"
                                        >
                                          <div>
                                            <div className="flex justify-between items-start gap-2 mb-2.5">
                                              <span className={`inline-block px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider ${
                                                isIncome 
                                                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                                                  : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                                              }`}>
                                                {isIncome ? 'Income Source' : 'Expense Outflow'}
                                              </span>
                                              <span className={`inline-block px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider ${
                                                evt.status === 'completed' 
                                                  ? 'bg-slate-100 text-slate-600 border border-slate-200' 
                                                  : evt.status === 'active' 
                                                    ? 'bg-emerald-50/50 text-emerald-600 border border-emerald-150' 
                                                    : 'bg-amber-50/50 text-amber-600 border border-amber-150 animate-pulse'
                                              }`}>
                                                {evt.status}
                                              </span>
                                            </div>
                                            <h5 className="text-sm font-extrabold text-slate-800 leading-tight">
                                              {evt.name}
                                            </h5>
                                            <p className="text-[10px] font-bold text-indigo-600 mt-0.5 tracking-wider uppercase">
                                              {evt.dateRange}
                                            </p>
                                            <p className="text-[11px] text-slate-400 mt-1.5 leading-relaxed font-semibold">
                                              {evt.description}
                                            </p>
                                          </div>

                                          <div className="border-t border-slate-100 mt-4 pt-3 flex justify-between items-center text-xs">
                                            {isIncome ? (
                                              <div>
                                                <span className="text-[10px] font-bold text-slate-400 block uppercase tracking-wider">
                                                  {getStatusForMonth(selectedYear, index) === 'Not Yet' ? 'BUDGETED INCOME' : 'INCOME RECEIVED'}
                                                </span>
                                                <span className="font-mono font-black text-emerald-600 text-sm">
                                                  +${evt.budget.toLocaleString()}
                                                </span>
                                              </div>
                                            ) : (
                                              <>
                                                <div>
                                                  <span className="text-[10px] font-bold text-slate-400 block uppercase tracking-wider text-left">BUDGET</span>
                                                  <span className="font-mono font-bold text-slate-600">
                                                    ${evt.budget.toLocaleString()}
                                                  </span>
                                                </div>
                                                <div className="text-right">
                                                  <span className="text-[10px] font-bold text-slate-400 block uppercase tracking-wider text-right">
                                                    {getStatusForMonth(selectedYear, index) === 'Not Yet' ? 'ESTIMATED SPENT' : 'SPENT'}
                                                  </span>
                                                  <span className={`font-mono font-black text-sm ${(getStatusForMonth(selectedYear, index) === 'Not Yet' ? evt.budget : evt.spent) > evt.budget ? 'text-rose-600' : 'text-slate-800'}`}>
                                                    ${(getStatusForMonth(selectedYear, index) === 'Not Yet' ? evt.budget : evt.spent).toLocaleString()}
                                                  </span>
                                                </div>
                                              </>
                                            )}
                                          </div>
                                        </div>
                                      );
                                    })}
                                  </div>
                                )}
                              </div>
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </section>

        {/* Static Event Comparative Analytics */}
        <section className="font-sans">
          <h2 className="text-lg font-bold text-slate-800 mb-4">Aesthetic Metrics Summary</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 flex flex-col justify-between min-h-[140px] shadow-sm">
              <div>
                <span className="text-[10px] font-bold text-slate-450 text-slate-400 block uppercase tracking-wider mb-1">BUDGET ENHANCEMENT</span>
                <p className="text-sm font-semibold text-slate-500">Overall year-over-year planned capacity increase.</p>
              </div>
              <div className="flex items-baseline gap-1.5 text-indigo-600">
                <span className="text-3xl font-extrabold">+18.5%</span>
                <TrendingUp className="h-5 w-5 font-bold" />
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 flex flex-col justify-between min-h-[140px] shadow-sm">
              <div>
                <span className="text-[10px] font-bold text-slate-450 text-slate-400 block uppercase tracking-wider mb-1">SAVINGS CONFINES</span>
                <p className="text-sm font-semibold text-slate-500">Retained reserve pool accumulated during seasons.</p>
              </div>
              <div className="flex items-baseline gap-1.5 text-emerald-600">
                <span className="text-3xl font-extrabold">$6,915.00</span>
                <Landmark className="h-5 w-5" />
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 flex flex-col justify-between min-h-[140px] shadow-sm">
              <div>
                <span className="text-[10px] font-bold text-slate-450 text-slate-400 block uppercase tracking-wider mb-1">ERRATIC EXTREMUMS</span>
                <p className="text-sm font-semibold text-slate-500">Unanticipated emergency out-of-budget spikes.</p>
              </div>
              <div className="flex items-baseline gap-1.5 text-rose-500">
                <span className="text-3xl font-extrabold">-2.4%</span>
                <TrendingDown className="h-5 w-5" />
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Nav Spec Expected footer mapping links */}
      <footer className="fixed bottom-0 left-0 w-full z-50 flex justify-around items-center px-4 py-2 bg-white border-t border-slate-200 shadow-lg rounded-t-2xl md:hidden">
        <a
          onClick={() => setScreen('EVENT_OVERVIEW')}
          className="flex flex-col items-center justify-center text-slate-500 hover:text-indigo-600 transition-all scale-95 hover:scale-105 active:scale-90 cursor-pointer py-1.5"
        >
          <span className="material-symbols-outlined">today</span>
          <span className="text-[10px] font-semibold uppercase tracking-wider mt-0.5">Overview</span>
        </a>

        <a
          onClick={() => setScreen('TRANSACTION_LEDGER')}
          className="flex flex-col items-center justify-center text-slate-500 hover:text-indigo-600 transition-all scale-95 hover:scale-105 active:scale-90 cursor-pointer py-1.5"
        >
          <span className="material-symbols-outlined">calendar_view_month</span>
          <span className="text-[10px] font-semibold uppercase tracking-wider mt-0.5">Ledger</span>
        </a>

        <a
          onClick={() => setScreen('MANAGE_EVENTS')}
          className="flex flex-col items-center justify-center text-slate-500 hover:text-indigo-600 transition-all scale-95 hover:scale-105 active:scale-90 cursor-pointer py-1.5"
        >
          <span className="material-symbols-outlined">calendar_month</span>
          <span className="text-[10px] font-semibold uppercase tracking-wider mt-0.5">Events</span>
        </a>
      </footer>
    </div>
  );
}
