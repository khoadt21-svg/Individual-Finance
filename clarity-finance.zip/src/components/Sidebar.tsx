import React from 'react';
import { 
  LayoutDashboard, 
  ReceiptText, 
  Compass, 
  TrendingUp, 
  Calendar, 
  Tags, 
  PlusCircle, 
  X,
  TrendingDown
} from 'lucide-react';
import { ScreenType } from '../types';

interface SidebarProps {
  currentScreen: ScreenType;
  onNavigate: (screen: ScreenType) => void;
  isOpenMobile?: boolean;
  onCloseMobile?: () => void;
}

export default function Sidebar({
  currentScreen,
  onNavigate,
  isOpenMobile = false,
  onCloseMobile
}: SidebarProps) {
  const menuItems = [
    {
      screen: 'EVENT_OVERVIEW' as ScreenType,
      label: 'Overview',
      icon: LayoutDashboard,
      description: 'Milestone tracking stats'
    },
    {
      screen: 'TRANSACTION_LEDGER' as ScreenType,
      label: 'Ledger',
      icon: ReceiptText,
      description: 'All transaction history'
    },
    {
      screen: 'EVENT_BUDGET_PLANNER' as ScreenType,
      label: 'Budget Planner',
      icon: Compass,
      description: 'Plan active milestone pools'
    },
    {
      screen: 'YEARLY_SUMMARY' as ScreenType,
      label: 'Yearly Summary',
      icon: TrendingUp,
      description: 'Historical performance'
    },
    {
      screen: 'MANAGE_EVENTS' as ScreenType,
      label: 'Manage Events',
      icon: Calendar,
      description: 'Milestone settings'
    },
    {
      screen: 'MANAGE_CATEGORIES' as ScreenType,
      label: 'Manage Categories',
      icon: Tags,
      description: 'Transaction categories'
    },
    {
      screen: 'LOG_TRANSACTION' as ScreenType,
      label: 'Log Transaction',
      icon: PlusCircle,
      description: 'Quick entry tool'
    }
  ];

  const handleItemClick = (screen: ScreenType) => {
    onNavigate(screen);
    if (onCloseMobile) {
      onCloseMobile();
    }
  };

  const renderContent = () => (
    <div className="flex flex-col h-full bg-white select-none">
      {/* Brand Header */}
      <div className="px-6 py-7 border-b border-slate-100 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-600 flex items-center justify-center text-white shadow-md shadow-indigo-100">
            <span className="material-symbols-outlined font-bold text-[22px]">account_balance_wallet</span>
          </div>
          <div>
            <h2 className="text-base font-extrabold text-slate-800 tracking-tight leading-none">Individual Finance</h2>
            <span className="text-[10px] font-bold text-indigo-600 tracking-wider uppercase mt-1 block">EVENT-CENTRIC</span>
          </div>
        </div>
        {onCloseMobile && (
          <button 
            onClick={onCloseMobile}
            className="md:hidden p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-full transition-all cursor-pointer"
            aria-label="Close menu"
          >
            <X className="h-5 w-5" />
          </button>
        )}
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 px-4 py-6 space-y-1.5 overflow-y-auto scrollbar-none font-sans">
        <span className="px-3 text-[10px] font-bold tracking-widest text-slate-400 uppercase block mb-3">
          Main Dashboard
        </span>
        {menuItems.map((item) => {
          const isActive = currentScreen === item.screen;
          const Icon = item.icon;
          return (
            <button
              key={item.screen}
              onClick={() => handleItemClick(item.screen)}
              className={`w-full flex items-center gap-3.5 px-3 py-3 rounded-xl transition-all duration-250 cursor-pointer text-left group ${
                isActive
                  ? 'bg-indigo-50 text-indigo-600 font-bold'
                  : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50/80 font-medium'
              }`}
            >
              <div className={`p-1.5 rounded-lg transition-transform duration-200 group-hover:scale-105 ${
                isActive ? 'bg-indigo-100/70 text-indigo-600' : 'bg-slate-50 text-slate-400 group-hover:text-slate-600'
              }`}>
                <Icon className="h-5 w-5" />
              </div>
              <div className="flex-grow">
                <span className="text-sm block leading-tight">{item.label}</span>
                <span className={`text-[10px] font-medium leading-tight block mt-0.5 ${
                  isActive ? 'text-indigo-400' : 'text-slate-400'
                }`}>
                  {item.description}
                </span>
              </div>
              {isActive && (
                <div className="w-1.5 h-6 rounded-full bg-indigo-650 bg-indigo-600"></div>
              )}
            </button>
          );
        })}
      </nav>

      {/* User Session card footer */}
      <div className="p-4 border-t border-slate-100 bg-slate-50/50">
        <div className="flex items-center gap-3 p-2 rounded-xl">
          <img
            alt="User profile"
            className="w-9 h-9 rounded-full object-cover border border-slate-205 border-slate-200"
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuAAZzIf448Bn_RANjG1kuP9eKEgANCvvh6trVO6j_C2qbeI6B76RpWW5wt-j1lfZ0qcZ9sS90pA1OUDRSo1pe0a_e-tmJ9q40pjtz8jFWYtbrYjtnDN__gHHy0QjTa599380Rl7a3GW4rxdQMC1ioYGhX9DYs3F934w5XA9JASPwxPVUfIgGxMCAdFGDnV5cxbYTTgZpb95b8GHAgZMYcHgb4VFw4vPFqFyrceTzKvIATvfUXBbA7InuHpE5zud23O0nwj3xH0Zhrs"
          />
          <div className="overflow-hidden">
            <h4 className="text-xs font-bold text-slate-800 leading-none truncate">John Doe</h4>
            <span className="text-[10px] text-slate-400 font-semibold truncate block mt-1">Premium Tracker</span>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside className="hidden md:flex flex-col w-64 border-r border-slate-200 bg-white sticky top-0 h-screen select-none shrink-0 z-50">
        {renderContent()}
      </aside>

      {/* Mobile Sidebar Overlay Drawer */}
      {isOpenMobile && (
        <div className="md:hidden fixed inset-0 z-[100] flex">
          {/* Backdrop with transition */}
          <div 
            className="fixed inset-0 bg-[#0b1c30]/40 backdrop-blur-xs transition-opacity duration-300"
            onClick={onCloseMobile}
          ></div>
          
          {/* Menu Drawer slide in */}
          <div className="relative flex flex-col w-72 max-w-[85vw] h-full bg-white shadow-2xl animate-slide-right overflow-hidden">
            {renderContent()}
          </div>
        </div>
      )}
    </>
  );
}
