import React, { useState } from 'react';
import { Event } from '../types';

interface ManageEventsProps {
  events: Event[];
  onAddEvent: (newEvent: Omit<Event, 'id'>) => void;
  onEditEvent: (id: string, updatedEvent: Omit<Event, 'id'>) => void;
  onDeleteEvent: (id: string) => void;
  setScreen: (screen: 'EVENT_OVERVIEW' | 'LOG_TRANSACTION' | 'TRANSACTION_LEDGER' | 'EVENT_BUDGET_PLANNER' | 'EVENT_BUDGET_DETAIL' | 'MANAGE_EVENTS' | 'MANAGE_CATEGORIES' | 'YEARLY_SUMMARY') => void;
  onMenuClick?: () => void;
}

export default function ManageEvents({
  events,
  onAddEvent,
  onEditEvent,
  onDeleteEvent,
  setScreen,
  onMenuClick
}: ManageEventsProps) {
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState('');
  const [budget, setBudget] = useState(1000);
  const [spent, setSpent] = useState(0);
  const [selectedMonth, setSelectedMonth] = useState('June');
  const [selectedYear, setSelectedYear] = useState('2026');
  const [description, setDescription] = useState('');
  const [type, setType] = useState<'income' | 'expense'>('expense');
  const [status, setStatus] = useState<'active' | 'upcoming' | 'completed'>('upcoming');
  const [icon, setIcon] = useState('Plane');
  const [editingEventId, setEditingEventId] = useState<string | null>(null);

  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  const years = ['2024', '2025', '2026', '2027', '2028', '2029', '2030'];

  const getEventIcon = (iconName: string) => {
    switch (iconName) {
      case 'Plane': return 'flight';
      case 'Anchor': return 'anchor';
      case 'FileText': return 'description';
      case 'TrendingUp': return 'trending_up';
      case 'Cloth': return 'checkroom';
      case 'Debt': return 'payments';
      case 'Investment': return 'show_chart';
      default: return 'calendar_month';
    }
  };

  const handleCloseForm = () => {
    setName('');
    setBudget(1000);
    setSpent(0);
    setSelectedMonth('June');
    setSelectedYear('2026');
    setDescription('');
    setType('expense');
    setStatus('upcoming');
    setIcon('Plane');
    setEditingEventId(null);
    setShowForm(false);
  };

  const handleStartEdit = (evt: Event) => {
    setName(evt.name);
    setBudget(evt.budget);
    setSpent(evt.spent);
    setDescription(evt.description);
    setType(evt.type || 'expense');
    setStatus(evt.status);
    setIcon(evt.icon);
    setEditingEventId(evt.id);

    // Parse month and year from evt.dateRange (e.g. "June 2026")
    const parts = evt.dateRange.trim().split(/\s+/);
    let parsedMonth = 'June';
    let parsedYear = '2026';

    if (parts.length > 0) {
      const matchMonth = months.find((m) =>
        m.toLowerCase().startsWith(parts[0].toLowerCase().substring(0, 3))
      );
      if (matchMonth) {
        parsedMonth = matchMonth;
      }
    }
    
    const yearMatch = evt.dateRange.match(/\b(20\d{2})\b/);
    if (yearMatch && years.includes(yearMatch[1])) {
      parsedYear = yearMatch[1];
    }

    setSelectedMonth(parsedMonth);
    setSelectedYear(parsedYear);
    setShowForm(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const finalDateRange = `${selectedMonth} ${selectedYear}`;
    const eventData = {
      name: name.trim(),
      budget: Number(budget),
      spent: type === 'income' ? 0 : Number(spent),
      dateRange: finalDateRange,
      description: description.trim() || `${type === 'income' ? 'Income inflow source' : 'Expense outlays'} for ${finalDateRange}`,
      icon,
      status,
      type
    };

    if (editingEventId) {
      onEditEvent(editingEventId, eventData);
    } else {
      onAddEvent(eventData);
    }

    handleCloseForm();
  };

  return (
    <div className="bg-slate-50 text-slate-900 min-h-screen pb-32">
      {/* TopAppBar */}
      <header className="bg-white border-b border-slate-200 w-full sticky top-0 z-40">
        <div className="flex flex-col sm:flex-row justify-between items-stretch sm:items-center px-4 md:px-8 py-3 sm:py-0 min-h-[5rem] sm:h-20 gap-3 w-full max-w-[1200px] mx-auto">
          <div className="flex items-center gap-2 md:gap-3">
            {onMenuClick && (
              <button
                onClick={onMenuClick}
                className="md:hidden text-slate-500 hover:bg-slate-100 p-2 rounded-full cursor-pointer flex items-center justify-center -ml-1 mr-1 shrink-0"
                aria-label="Open navigation menu"
              >
                <span className="material-symbols-outlined text-[24px]">menu</span>
              </button>
            )}
            <div className="min-w-0">
              <h1 className="text-base sm:text-lg font-bold text-slate-900 leading-tight">Manage Events</h1>
              <p className="text-xs text-slate-500 hidden sm:block">Manage app configurations &amp; details</p>
            </div>
          </div>
          <div className="flex items-center justify-end shrink-0">
            <div className="w-10 h-10 rounded-full bg-slate-50 border border-slate-200 overflow-hidden">
              <img
                alt="Profile Avatar"
                className="w-full h-full object-cover"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuAAZzIf448Bn_RANjG1kuP9eKEgANCvvh6trVO6j_C2qbeI6B76RpWW5wt-j1lfZ0qcZ9sS90pA1OUDRSo1pe0a_e-tmJ9q40pjtz8jFWYtbrYjtnDN__gHHy0QjTa599380Rl7a3GW4rxdQMC1ioYGhX9DYs3F934w5XA9JASPwxPVUfIgGxMCAdFGDnV5cxbYTTgZpb95b8GHAgZMYcHgb4VFw4vPFqFyrceTzKvIATvfUXBbA7InuHpE5zud23O0nwj3xH0Zhrs"
              />
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-[1200px] mx-auto px-4 md:px-8 py-6 font-sans">
        {/* Title Block */}
        <section className="mb-6">
          <div className="flex flex-col gap-1 mb-2">
            <h2 className="text-2xl font-extrabold text-slate-900 leading-tight">Manage Events</h2>
            <p className="text-slate-500 text-sm">Manage your organization and financial tracking preferences.</p>
          </div>
        </section>

        {/* Managed Events details */}
        <section className="space-y-6">
          <div className="flex justify-between items-center flex-wrap gap-2">
            <h3 className="text-lg font-bold text-slate-800">Managed Events</h3>
            <button
              onClick={() => setShowForm(!showForm)}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2.5 rounded-xl font-bold text-xs tracking-wider uppercase transition-all shadow-sm active:scale-95 cursor-pointer"
            >
              <span className="material-symbols-outlined text-sm font-bold">add</span>
              {showForm ? 'Close Form' : 'Add New Event'}
            </button>
          </div>

          {showForm && (
            <form onSubmit={handleSubmit} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-md space-y-4 animate-fade-in mb-8 text-left">
              <div className="flex justify-between items-center border-b border-slate-100 pb-3 mb-2">
                <h4 className="text-sm font-extrabold text-indigo-700 uppercase tracking-widest">
                  {editingEventId ? 'Edit Event' : 'Create New Event'}
                </h4>
                <button
                  type="button"
                  onClick={handleCloseForm}
                  className="text-slate-400 hover:text-slate-600 font-bold text-sm cursor-pointer"
                >
                  ✕ Close
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Event Name */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Event Name</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. August 2026 Revenue"
                    className="border border-slate-200 outline-none focus:border-indigo-500 rounded-xl px-3 py-2 text-sm font-medium"
                    required
                  />
                </div>

                {/* Event Type selection */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Event Type</label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as 'income' | 'expense')}
                    className="border border-slate-200 outline-none focus:border-indigo-500 rounded-xl px-3 py-2 text-sm bg-white font-medium cursor-pointer"
                  >
                    <option value="expense">Expense Outflow (spent/bills)</option>
                    <option value="income">Income Inflow (salaries/dividends)</option>
                  </select>
                </div>

                {/* Period selection */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Period</label>
                  <div className="grid grid-cols-2 gap-2">
                    <select
                      value={selectedMonth}
                      onChange={(e) => setSelectedMonth(e.target.value)}
                      className="border border-slate-200 outline-none focus:border-indigo-500 rounded-xl px-3 py-2 text-sm bg-white font-medium cursor-pointer"
                    >
                      {months.map((m) => (
                        <option key={m} value={m}>{m}</option>
                      ))}
                    </select>
                    <select
                      value={selectedYear}
                      onChange={(e) => setSelectedYear(e.target.value)}
                      className="border border-slate-200 outline-none focus:border-indigo-500 rounded-xl px-3 py-2 text-sm bg-white font-medium cursor-pointer"
                    >
                      {years.map((y) => (
                        <option key={y} value={y}>{y}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Value amount (budget) */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    {type === 'income' ? 'Total Income ($)' : 'Budget Max ($)'}
                  </label>
                  <input
                    type="number"
                    value={budget}
                    onChange={(e) => setBudget(Number(e.target.value))}
                    min="0"
                    placeholder="2500"
                    className="border border-slate-200 outline-none focus:border-indigo-500 rounded-xl px-3 py-2 text-sm font-medium"
                    required
                  />
                </div>

                {/* Actual Spent if expense */}
                {type === 'expense' && (
                  <div className="flex flex-col gap-1.5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Actual Spent ($)</label>
                    <input
                      type="number"
                      value={spent}
                      onChange={(e) => setSpent(Number(e.target.value))}
                      min="0"
                      placeholder="0"
                      className="border border-slate-200 outline-none focus:border-indigo-500 rounded-xl px-3 py-2 text-sm font-medium"
                    />
                  </div>
                )}

                {/* Status selection */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Status</label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as 'active' | 'upcoming' | 'completed')}
                    className="border border-slate-200 outline-none focus:border-indigo-500 rounded-xl px-3 py-2 text-sm bg-white font-medium cursor-pointer"
                  >
                    <option value="upcoming">Upcoming</option>
                    <option value="active">Active</option>
                    <option value="completed">Completed</option>
                  </select>
                </div>

                {/* Description */}
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Description</label>
                  <textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Short description summary..."
                    rows={2}
                    className="border border-slate-200 outline-none focus:border-indigo-500 rounded-xl px-3 py-2 text-sm font-medium"
                  />
                </div>

                {/* Icon option */}
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Aesthetic Icon</label>
                  <div className="flex gap-4 flex-wrap mt-0.5">
                    {[
                      { name: 'Plane', label: 'Flight/Vacation' },
                      { name: 'Anchor', label: 'Travel/Marine' },
                      { name: 'FileText', label: 'Bills/Documents' },
                      { name: 'TrendingUp', label: 'Salary/Inflow' },
                      { name: 'Cloth', label: 'Cloth/Apparel' },
                      { name: 'Debt', label: 'Debt/Repayments' },
                      { name: 'Investment', label: 'Investment/Assets' }
                    ].map((item) => (
                      <button
                        type="button"
                        key={item.name}
                        onClick={() => setIcon(item.name)}
                        className={`px-3 py-2 text-xs rounded-xl border flex items-center gap-1.5 cursor-pointer transition-all ${
                          icon === item.name 
                            ? 'bg-indigo-600 text-white border-indigo-600 font-bold' 
                            : 'bg-white text-slate-600 hover:bg-slate-50 border-slate-200 font-medium'
                        }`}
                      >
                        <span className="material-symbols-outlined text-[16px]">
                          {getEventIcon(item.name)}
                        </span>
                        {item.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={handleCloseForm}
                  className="px-4 py-2 border border-slate-200 rounded-xl text-slate-500 hover:bg-slate-50 text-xs font-bold uppercase transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer shadow-sm"
                >
                  {editingEventId ? 'Save Changes' : 'Create Event'}
                </button>
              </div>
            </form>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {events.map((evt) => (
              <div
                key={evt.id}
                className="bg-white p-5 rounded-2xl border border-slate-200 flex flex-col justify-between hover:shadow-md transition-shadow group min-h-[170px]"
              >
                <div className="flex justify-between items-start mb-4">
                  <div className="p-2.5 bg-indigo-50 rounded-xl text-indigo-650 text-indigo-600">
                    <span className="material-symbols-outlined text-[22px] font-bold">
                      {getEventIcon(evt.icon)}
                    </span>
                  </div>
                  <div className="flex gap-1.5 opacity-80 group-hover:opacity-100 transition-opacity">
                    <button
                      type="button"
                      onClick={() => handleStartEdit(evt)}
                      className="p-2 text-slate-400 hover:text-indigo-600 transition-colors rounded-full hover:bg-slate-50 cursor-pointer"
                      title="Edit event"
                    >
                      <span className="material-symbols-outlined text-[18px]">edit</span>
                    </button>
                    {events.length > 1 && (
                      <button
                        type="button"
                        onClick={() => onDeleteEvent(evt.id)}
                        className="p-2 text-slate-400 hover:text-rose-600 transition-colors rounded-full hover:bg-slate-50 cursor-pointer"
                        title="Delete event"
                      >
                        <span className="material-symbols-outlined text-[18px]">delete</span>
                      </button>
                    )}
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-bold text-slate-800">{evt.name}</h4>
                  <p className="text-[11px] font-bold text-indigo-600 uppercase tracking-widest mt-1 mb-1.5">{evt.dateRange}</p>
                  <p className="text-[11px] text-slate-400 font-semibold">{evt.description}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Aesthetic Explainer Block */}
        <div className="mt-14 grid grid-cols-1 md:grid-cols-2 gap-8 items-center border-t border-slate-200 pt-10">
          <div>
            <h3 className="text-2xl font-extrabold text-slate-800 mb-3 leading-tight">Why organize?</h3>
            <p className="text-slate-500 leading-relaxed font-semibold text-sm mb-6">
              Effective categorization and event grouping reduce the complexity of financial analysis. By segregating data into meaningful buckets, you gain high-confidence insights into your spending habits.
            </p>
            <div className="flex gap-6 flex-wrap font-bold text-xs uppercase tracking-wider text-slate-600">
              <div className="flex items-center gap-1">
                <span className="material-symbols-outlined text-emerald-500 font-bold">check_circle</span>
                <span>Accuracy</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="material-symbols-outlined text-indigo-500 font-bold">check_circle</span>
                <span>Clarity</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="material-symbols-outlined text-rose-500 font-bold">check_circle</span>
                <span>Speed</span>
              </div>
            </div>
          </div>
          <div className="h-60 rounded-3xl overflow-hidden border border-slate-200 shadow-sm">
            <img
              className="w-full h-full object-cover"
              alt="Data visualization illustration"
              src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=600"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      </main>

      {/* Nav Spec Expected footer mapping links with icons dashboard/receipt_long/pie_chart */}
      <footer className="fixed bottom-0 left-0 w-full z-50 flex justify-around items-center px-4 py-2 bg-white border-t border-slate-200 shadow-lg rounded-t-2xl md:hidden">
        <a
          onClick={() => setScreen('EVENT_OVERVIEW')}
          className="flex flex-col items-center justify-center text-slate-500 hover:text-indigo-600 transition-all scale-95 hover:scale-105 active:scale-90 cursor-pointer py-1.5"
        >
          <span className="material-symbols-outlined">dashboard</span>
          <span className="text-[10px] font-semibold uppercase tracking-wider mt-0.5">Overview</span>
        </a>

        <a
          onClick={() => setScreen('TRANSACTION_LEDGER')}
          className="flex flex-col items-center justify-center text-slate-500 hover:text-indigo-600 transition-all scale-95 hover:scale-105 active:scale-90 cursor-pointer py-1.5"
        >
          <span className="material-symbols-outlined">receipt_long</span>
          <span className="text-[10px] font-semibold uppercase tracking-wider mt-0.5">Ledger</span>
        </a>

        <a
          onClick={() => setScreen('YEARLY_SUMMARY')}
          className="flex flex-col items-center justify-center text-slate-500 hover:text-indigo-600 transition-all scale-95 hover:scale-105 active:scale-90 cursor-pointer py-1.5"
        >
          <span className="material-symbols-outlined">pie_chart</span>
          <span className="text-[10px] font-semibold uppercase tracking-wider mt-0.5">Budget</span>
        </a>
      </footer>
    </div>
  );
}
