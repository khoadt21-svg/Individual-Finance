import React, { useState, useEffect } from 'react';
import { ArrowLeft, CheckCircle, Copy, ChevronDown } from 'lucide-react';
import { Event } from '../types';

interface EventBudgetDetailProps {
  events: Event[];
  onSave: (eventId: string, amt: number) => void;
  setScreen: (screen: 'EVENT_OVERVIEW' | 'LOG_TRANSACTION' | 'TRANSACTION_LEDGER' | 'EVENT_BUDGET_PLANNER' | 'EVENT_BUDGET_DETAIL' | 'MANAGE_EVENTS' | 'MANAGE_CATEGORIES' | 'YEARLY_SUMMARY') => void;
}

export default function EventBudgetDetail({
  events,
  onSave,
  setScreen
}: EventBudgetDetailProps) {
  // Find events that do not have detailed budget planning in localStorage
  const unplannedEvents = events.filter((e) => {
    const hasDetailed = localStorage.getItem(`event_detailed_budget_${e.id}`);
    return !hasDetailed;
  });

  // Candidates for the "Select Event" dropdown.
  // We prioritize unplanned events, but if all are planned, we show all events so the user can edit as needed.
  const selectCandidates = unplannedEvents.length > 0 ? unplannedEvents : events;

  const [selectedEventId, setSelectedEventId] = useState<string>(() => {
    // Default to 'evt-summer' if available, otherwise the first eligible candidate
    const summer = selectCandidates.find((e) => e.id === 'evt-summer');
    return summer ? summer.id : (selectCandidates[0]?.id || '');
  });

  const selectedEvent: Event = events.find((e) => e.id === selectedEventId) || events[0] || {
    id: '',
    name: 'No Active Event Selected',
    budget: 0,
    spent: 0,
    dateRange: 'N/A',
    description: 'Please select or add an event first.',
    icon: 'event',
    status: 'upcoming',
    type: 'expense'
  };

  const [transport, setTransport] = useState<string>('');
  const [food, setFood] = useState<string>('');
  const [lodging, setLodging] = useState<string>('');
  const [activities, setActivities] = useState<string>('');
  const [isSaving, setIsSaving] = useState(false);
  const [showCopyDropdown, setShowCopyDropdown] = useState(false);

  // Dynamically load existing values on event change
  useEffect(() => {
    if (!selectedEvent.id) return;
    const saved = localStorage.getItem(`event_detailed_budget_${selectedEvent.id}`);
    if (saved) {
      try {
        const data = JSON.parse(saved);
        setTransport(data.transport || '');
        setFood(data.food || '');
        setLodging(data.lodging || '');
        setActivities(data.activities || '');
      } catch (err) {
        setTransport('');
        setFood('');
        setLodging('');
        setActivities('');
      }
    } else {
      setTransport('');
      setFood('');
      setLodging('');
      setActivities('');
    }
  }, [selectedEvent.id]);

  // Calculate sum of inputs
  const tAmt = parseFloat(transport) || 0;
  const fAmt = parseFloat(food) || 0;
  const lAmt = parseFloat(lodging) || 0;
  const aAmt = parseFloat(activities) || 0;
  const totalBudget = tAmt + fAmt + lAmt + aAmt;

  const handleSave = () => {
    if (!selectedEvent.id) return;
    setIsSaving(true);
    setTimeout(() => {
      // Save detailed categories to local storage
      localStorage.setItem(
        `event_detailed_budget_${selectedEvent.id}`,
        JSON.stringify({
          transport: transport.toString(),
          food: food.toString(),
          lodging: lodging.toString(),
          activities: activities.toString()
        })
      );

      // Save overall budget in global state
      onSave(selectedEvent.id, totalBudget);

      setIsSaving(false);
      setScreen('EVENT_BUDGET_PLANNER');
    }, 600);
  };

  const handleCopyBudgetFrom = (sourceId: string) => {
    const sourceEvent = events.find((ev) => ev.id === sourceId);
    if (!sourceEvent) return;

    const savedData = localStorage.getItem(`event_detailed_budget_${sourceId}`);
    if (savedData) {
      try {
        const data = JSON.parse(savedData);
        setTransport(data.transport || '');
        setFood(data.food || '');
        setLodging(data.lodging || '');
        setActivities(data.activities || '');
      } catch (e) {
        // Fallback proportionally
        const portion = (sourceEvent.budget / 4).toFixed(0);
        setTransport(portion);
        setFood(portion);
        setLodging(portion);
        setActivities(portion);
      }
    } else {
      // Split proportionally
      const portion = (sourceEvent.budget / 4).toFixed(0);
      setTransport(portion);
      setFood(portion);
      setLodging(portion);
      setActivities(portion);
    }
    setShowCopyDropdown(false);
  };

  return (
    <div className="bg-slate-50 text-slate-900 min-h-screen pb-32">
      {/* Top AppBar */}
      <header className="fixed top-0 w-full z-50 bg-white/95 backdrop-blur-md border-b border-slate-200 h-20 flex items-center justify-between px-4 md:px-8">
        <div className="flex items-center gap-4">
          <button
            onClick={() => setScreen('EVENT_BUDGET_PLANNER')}
            className="text-indigo-600 p-2 rounded-full hover:bg-slate-100 transition-colors flex items-center cursor-pointer"
          >
            <span className="material-symbols-outlined">arrow_back</span>
          </button>
          <h1 className="text-lg font-bold text-slate-900 leading-tight">Event Budget Planner</h1>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-[10px] font-bold text-slate-400 id-status uppercase tracking-widest hidden md:block">
            ESTIMATING
          </span>
          <div className="w-10 h-10 rounded-full bg-indigo-650 bg-indigo-600 flex items-center justify-center text-white font-extrabold text-sm shadow-sm font-sans">
            JD
          </div>
        </div>
      </header>

      <main className="pt-28 px-4 md:px-8 max-w-[1200px] mx-auto">
        {/* Event Selection Selector */}
        <section className="mb-6 mt-4">
          <div className="bg-white border border-slate-200 p-5 rounded-2xl shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-[10px] font-bold tracking-widest text-indigo-600 uppercase block mb-1">
                Select Event to Design Budget
              </span>
              <p className="text-xs text-slate-500">
                Choose an existing event to plan category details
              </p>
            </div>
            <div className="relative min-w-[280px]">
              <select
                value={selectedEventId}
                onChange={(e) => setSelectedEventId(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-800 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-600 outline-none transition-all appearance-none cursor-pointer pr-10"
              >
                {/* Highlight unbudgeted events */}
                <optgroup label="Events Needing Detailed Planning">
                  {events
                    .filter((e) => !localStorage.getItem(`event_detailed_budget_${e.id}`))
                    .map((e) => (
                      <option key={e.id} value={e.id}>
                        {e.name} ({e.dateRange})
                      </option>
                    ))}
                </optgroup>
                <optgroup label="Other Events">
                  {events
                    .filter((e) => localStorage.getItem(`event_detailed_budget_${e.id}`))
                    .map((e) => (
                      <option key={e.id} value={e.id}>
                        {e.name} (Planned • ${e.budget.toLocaleString()})
                      </option>
                    ))}
                </optgroup>
              </select>
              <ChevronDown className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none h-4.5 w-4.5" />
            </div>
          </div>
        </section>

        {/* Project Header details card */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8 font-sans">
          <div className="md:col-span-2 bg-white border border-slate-200 p-6 rounded-2xl flex flex-col justify-between min-h-[160px] shadow-sm">
            <div>
              <span className="text-[10px] font-bold tracking-widest text-indigo-600 mb-1 block uppercase">
                CURRENT PROJECT
              </span>
              <h2 className="text-2xl font-extrabold text-slate-800">{selectedEvent.name}</h2>
              <p className="text-xs text-slate-500 mt-1">{selectedEvent.description}</p>
            </div>
            <div className="flex gap-2.5 mt-4 flex-wrap">
              <span className="px-3.5 py-1.5 rounded-full bg-slate-100 text-slate-500 text-xs font-semibold flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[16px] font-bold">calendar_month</span>{' '}
                {selectedEvent.dateRange}
              </span>
              <span className="px-3.5 py-1.5 rounded-full bg-emerald-50 text-emerald-700 text-xs font-semibold flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[16px]">task_alt</span>{' '}
                {selectedEvent.status.toUpperCase()}
              </span>
            </div>
          </div>

          <div className="bg-indigo-600 p-6 rounded-2xl flex flex-col justify-center items-center text-white shadow-md border border-indigo-600">
            <span className="text-[10px] font-bold tracking-widest opacity-80 mb-1.5 text-center">
              TOTAL ESTIMATED BUDGET
            </span>
            <div className="text-4xl font-mono font-bold">
              ${totalBudget.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="w-full bg-white/20 h-1.5 rounded-full mt-4 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-emerald-400 to-green-500 rounded-full transition-all duration-300"
                style={{ width: `${Math.min((totalBudget / 10000) * 100, 100)}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* Input Lists for budget category items */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 font-sans">
          <div className="lg:col-span-8 flex flex-col gap-4">
            <div className="flex justify-between items-center mb-1">
              <h3 className="text-lg font-bold text-slate-800">Budget Categories</h3>

              {/* COPY BUDGET BUTTON */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowCopyDropdown(!showCopyDropdown)}
                  className="px-4 py-2 bg-indigo-50 hover:bg-indigo-100 border border-indigo-100 rounded-xl text-indigo-700 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
                >
                  <Copy className="h-3.5 w-3.5" />
                  <span>Copy budget from previous event</span>
                </button>

                {showCopyDropdown && (
                  <div className="absolute right-0 mt-2 w-72 bg-white rounded-2xl border border-slate-200 shadow-xl z-50 p-3 flex flex-col gap-2">
                    <span className="text-[10px] font-bold text-slate-400 block uppercase tracking-wider">
                      Select Source Event
                    </span>
                    <div className="max-h-56 overflow-y-auto space-y-1.5">
                      {events
                        .filter((e) => e.id !== selectedEvent.id)
                        .map((e) => (
                          <button
                            key={e.id}
                            type="button"
                            onClick={() => handleCopyBudgetFrom(e.id)}
                            className="w-full text-left p-2 hover:bg-slate-50 rounded-lg text-xs transition-colors flex flex-col gap-0.5 border border-slate-100"
                          >
                            <span className="font-bold text-slate-700">{e.name}</span>
                            <span className="text-[10px] text-slate-400">
                              Budget: ${e.budget.toLocaleString()} • {e.dateRange}
                            </span>
                          </button>
                        ))}
                      {events.filter((e) => e.id !== selectedEvent.id).length === 0 && (
                        <p className="text-xs text-slate-400 p-2 text-center">No previous events available.</p>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Transport Card */}
            <div className="bg-white border border-slate-200 p-5 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:shadow-md transition-all">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-indigo-50 flex items-center justify-center text-indigo-600 shrink-0">
                  <span className="material-symbols-outlined text-[24px]">flight</span>
                </div>
                <div className="min-w-0">
                  <label className="text-sm font-bold text-slate-800 block">Transport</label>
                  <p className="text-xs text-slate-400 mt-0.5 truncate sm:normal-case">Flights, rentals, and local transit</p>
                </div>
              </div>
              <div className="relative w-full sm:max-w-[160px]">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold">$</span>
                <input
                  type="number"
                  placeholder="0.00"
                  value={transport}
                  onChange={(e) => setTransport(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-8 pr-4 py-3 font-mono font-bold text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                />
              </div>
            </div>

            {/* Food Card */}
            <div className="bg-white border border-slate-200 p-5 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:shadow-md transition-all">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-indigo-50 flex items-center justify-center text-indigo-600 shrink-0">
                  <span className="material-symbols-outlined text-[24px]">restaurant</span>
                </div>
                <div className="min-w-0">
                  <label className="text-sm font-bold text-slate-800 block">Food &amp; Drinks</label>
                  <p className="text-xs text-slate-400 mt-0.5 truncate sm:normal-case">Dining out, groceries, and coffee</p>
                </div>
              </div>
              <div className="relative w-full sm:max-w-[160px]">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold">$</span>
                <input
                  type="number"
                  placeholder="0.00"
                  value={food}
                  onChange={(e) => setFood(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-8 pr-4 py-3 font-mono font-bold text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                />
              </div>
            </div>

            {/* Lodging Card */}
            <div className="bg-white border border-slate-200 p-5 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:shadow-md transition-all">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-indigo-50 flex items-center justify-center text-indigo-600 shrink-0">
                  <span className="material-symbols-outlined text-[24px]">hotel</span>
                </div>
                <div className="min-w-0">
                  <label className="text-sm font-bold text-slate-800 block">Lodging</label>
                  <p className="text-xs text-slate-400 mt-0.5 truncate sm:normal-case">Hotels, rentals, and stays</p>
                </div>
              </div>
              <div className="relative w-full sm:max-w-[160px]">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold">$</span>
                <input
                  type="number"
                  placeholder="0.00"
                  value={lodging}
                  onChange={(e) => setLodging(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-8 pr-4 py-3 font-mono font-bold text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                />
              </div>
            </div>

            {/* Activities Card */}
            <div className="bg-white border border-slate-200 p-5 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:shadow-md transition-all">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-indigo-50 flex items-center justify-center text-indigo-600 shrink-0">
                  <span className="material-symbols-outlined text-[24px]">local_activity</span>
                </div>
                <div className="min-w-0">
                  <label className="text-sm font-bold text-slate-800 block">Activities</label>
                  <p className="text-xs text-slate-400 mt-0.5 truncate sm:normal-case">Tours, tickets, and professional fun</p>
                </div>
              </div>
              <div className="relative w-full sm:max-w-[160px]">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold">$</span>
                <input
                  type="number"
                  placeholder="0.00"
                  value={activities}
                  onChange={(e) => setActivities(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-8 pr-4 py-3 font-mono font-bold text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                />
              </div>
            </div>
          </div>

          <div className="lg:col-span-4">
            <div className="flex flex-col gap-6 sticky top-28">
              <div className="bg-white border border-slate-200 p-5 rounded-2xl shadow-sm">
                <h4 className="text-sm font-bold text-slate-800 mb-3 block uppercase tracking-wider">Planning Tips</h4>
                <ul className="space-y-4">
                  <li className="flex gap-2.5 items-start">
                    <CheckCircle className="text-emerald-500 h-5 w-5 flex-shrink-0 mt-0.5" />
                    <span className="text-xs text-slate-500 leading-relaxed font-semibold">
                      Allocate 10% extra for unexpected incidental costs.
                    </span>
                  </li>
                  <li className="flex gap-2.5 items-start">
                    <CheckCircle className="text-emerald-500 h-5 w-5 flex-shrink-0 mt-0.5" />
                    <span className="text-xs text-slate-500 leading-relaxed font-semibold">
                      Copy from previous events if they ran in the same locations.
                    </span>
                  </li>
                </ul>
              </div>

              <div className="relative rounded-2xl h-48 overflow-hidden group shadow-sm border border-slate-200">
                <img
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  alt="Enjoy details"
                  src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&q=80&w=600"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/75 to-transparent flex items-end p-5">
                  <p className="text-white text-sm font-bold leading-relaxed">Enjoy your trip with confidence.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Bottom Action bar */}
      <div className="fixed bottom-0 left-0 w-full z-50 bg-white h-24 border-t border-slate-200 px-4 md:px-8 flex items-center justify-between shadow-lg">
        <div className="hidden md:flex flex-col font-sans">
          <span className="text-[10px] font-bold text-slate-404 text-slate-400 uppercase tracking-widest">
            ESTIMATED TOTAL
          </span>
          <span className="text-lg font-mono font-extrabold text-slate-800">
            ${totalBudget.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </span>
        </div>
        <div className="flex gap-3 w-full md:w-auto">
          <button
            onClick={() => setScreen('EVENT_BUDGET_PLANNER')}
            className="flex-1 md:flex-none px-8 py-3 rounded-full border border-slate-200 text-slate-500 font-bold text-xs uppercase tracking-wider hover:bg-slate-100 transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            id="save-btn"
            onClick={handleSave}
            disabled={!selectedEvent.id}
            className="flex-1 md:flex-none px-8 py-3 rounded-full bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs uppercase tracking-wider hover:shadow-md active:scale-95 transition-all flex items-center justify-center cursor-pointer"
          >
            {isSaving ? 'Saving...' : 'Save Event Budget'}
          </button>
        </div>
      </div>
    </div>
  );
}
