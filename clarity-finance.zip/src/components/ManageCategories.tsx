import React, { useState } from 'react';
import { Category } from '../types';

interface ManageCategoriesProps {
  categories: Category[];
  onAddCategory: (newCat: Omit<Category, 'id' | 'transactionCount'>) => void;
  onDeleteCategory: (id: string) => void;
  onEditCategory: (id: string, updatedFields: Omit<Category, 'id' | 'transactionCount'>) => void;
  setScreen: (screen: 'EVENT_OVERVIEW' | 'LOG_TRANSACTION' | 'TRANSACTION_LEDGER' | 'EVENT_BUDGET_PLANNER' | 'EVENT_BUDGET_DETAIL' | 'MANAGE_EVENTS' | 'MANAGE_CATEGORIES' | 'YEARLY_SUMMARY') => void;
  onMenuClick?: () => void;
}

export default function ManageCategories({
  categories,
  onAddCategory,
  onDeleteCategory,
  onEditCategory,
  setScreen,
  onMenuClick
}: ManageCategoriesProps) {
  const [showModal, setShowModal] = useState(false);
  const [editingCategoryId, setEditingCategoryId] = useState<string | null>(null);
  const [newCatName, setNewCatName] = useState('');
  const [newCatIcon, setNewCatIcon] = useState('Home');
  const [newCatColor, setNewCatColor] = useState('#6366f1');
  const [newCatType, setNewCatType] = useState<'expense' | 'income'>('expense');
  const [activeTab, setActiveTab] = useState<'expense' | 'income'>('expense');

  const handleOpenAddCategory = () => {
    setEditingCategoryId(null);
    setNewCatName('');
    setNewCatType(activeTab);
    setNewCatIcon('Home');
    setNewCatColor('#6366f1');
    setShowModal(true);
  };

  const handleOpenEditCategory = (cat: Category) => {
    setEditingCategoryId(cat.id);
    setNewCatName(cat.name);
    setNewCatType(cat.type || 'expense');
    setNewCatIcon(cat.icon || 'Home');
    setNewCatColor(cat.color || '#6366f1');
    setShowModal(true);
  };

  const handleSaveCategory = () => {
    if (!newCatName.trim()) return;
    
    if (editingCategoryId) {
      onEditCategory(editingCategoryId, {
        name: newCatName.trim(),
        type: newCatType,
        icon: newCatIcon,
        color: newCatColor
      });
    } else {
      onAddCategory({
        name: newCatName.trim(),
        type: newCatType,
        icon: newCatIcon,
        color: newCatColor
      });
    }
    
    setNewCatName('');
    setEditingCategoryId(null);
    setShowModal(false);
  };

  const getMatSymbol = (iconName: string) => {
    switch (iconName) {
      case 'Home': return 'home';
      case 'ShoppingCart': return 'shopping_cart';
      case 'Car': return 'directions_car';
      case 'Utensils': return 'restaurant';
      case 'Film': return 'movie';
      case 'Zap': return 'bolt';
      case 'HeartPulse': return 'medical_services';
      case 'Checkroom': return 'checkroom';
      case 'Payments': return 'payments';
      case 'ShowChart': return 'show_chart';
      case 'Savings': return 'savings';
      case 'Book': return 'menu_book';
      case 'Flight': return 'flight';
      case 'Work': return 'work';
      case 'Pets': return 'pets';
      case 'Gift': return 'card_giftcard';
      case 'Music': return 'music_note';
      case 'Coffee': return 'local_cafe';
      case 'MoreHorizontal': return 'more_horiz';
      default: return 'category';
    }
  };

  return (
    <div className="bg-slate-50 text-slate-900 min-h-screen pb-32">
      {/* TopAppBar */}
      <header className="bg-white border-b border-slate-200 w-full sticky top-0 z-40">
        <div className="flex flex-col sm:flex-row justify-between items-stretch sm:items-center px-4 md:px-8 py-3 sm:py-0 min-h-[5rem] sm:h-20 gap-3 w-full max-w-[1200px] mx-auto">
          <div className="flex items-center gap-2 md:gap-4">
            {onMenuClick && (
              <button
                onClick={onMenuClick}
                className="md:hidden text-slate-500 hover:bg-slate-100 p-2 rounded-full cursor-pointer flex items-center justify-center -ml-1 mr-1 shrink-0"
                aria-label="Open navigation menu"
              >
                <span className="material-symbols-outlined text-[24px]">menu</span>
              </button>
            )}
            <h1 className="text-base sm:text-lg font-bold text-slate-900 leading-tight">Individual Finance</h1>
          </div>
          <div className="flex items-center justify-end shrink-0">
            <div className="w-10 h-10 rounded-full overflow-hidden border border-slate-200">
              <img
                alt="Profile Avatar"
                className="w-full h-full object-cover"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuDlPPwTxq45l2DmBLoi6-YJRWa18ydDqNvGG2uaLS9mM5QlqtNlqMt76BPwkhqrQ5aGqMFNngU-XI6TEmtQ0F9CZQhsRuBuIU6xynOnMp47oCRZktI0uxuRaMEAjjw5u7krB8CjtE0cKs6QUoI587TSQ4BEqvMlSkPvatCKf6DgrFSXP5VoqPmR1uc6U6zSLe8tvRepsR1hIYrzvfBI6QB2QtM5Gzqo5V7BcGV7FMnBCirnAiLc_jFNA1wANM1zL0SsmktJNhNp1aQ"
              />
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-[1200px] mx-auto px-4 md:px-8 py-6 font-sans">
        {/* Header Title & Action Row */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
          <div>
            <h2 className="text-2xl font-extrabold text-slate-900 mb-1 leading-tight">Manage Categories</h2>
            <p className="text-sm font-semibold text-slate-550 text-slate-500 max-w-xl">
              Organize your financial flows with custom categories. Color-code your spending for high-confidence data visualization.
            </p>
          </div>
          <button
            onClick={handleOpenAddCategory}
            className="flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-full font-bold text-sm tracking-wider uppercase transition-all shadow-md hover:scale-[1.02] active:scale-95 cursor-pointer"
          >
            <span className="material-symbols-outlined font-bold">add_circle</span>
            Add Category
          </button>
        </div>

        {/* Segmented control triggers table */}
        <div className="flex p-1 bg-slate-100 rounded-2xl w-full md:w-fit mb-6">
          <button
            onClick={() => setActiveTab('expense')}
            className={`flex-1 md:w-32 py-2.5 px-5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all duration-200 cursor-pointer ${
              activeTab === 'expense'
                ? 'bg-white text-indigo-600 shadow-sm'
                : 'text-slate-400 hover:text-indigo-600'
            }`}
          >
            Expenses
          </button>
          <button
            id="tab-income"
            onClick={() => setActiveTab('income')}
            className={`flex-1 md:w-32 py-2.5 px-5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all duration-200 cursor-pointer ${
              activeTab === 'income'
                ? 'bg-white text-indigo-600 shadow-sm'
                : 'text-slate-400 hover:text-indigo-650'
            }`}
          >
            Income
          </button>
        </div>

        {/* Bento Grid layout for categories list selection */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {categories
            .filter((cat) => (cat.type || 'expense') === activeTab)
            .map((cat) => (
              <div
                key={cat.id}
                className="group bg-white border border-slate-200 rounded-2xl p-5 flex flex-col justify-between min-h-[160px] hover:shadow-md transition-all duration-300"
              >
                <div className="flex justify-between items-start">
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center"
                    style={{ backgroundColor: `${cat.color}15`, color: cat.color }}
                  >
                    <span className="material-symbols-outlined text-[24px] font-bold">
                      {getMatSymbol(cat.icon)}
                    </span>
                  </div>
                  <div className="flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => handleOpenEditCategory(cat)}
                      className="p-2 hover:bg-slate-50 text-slate-400 hover:text-indigo-600 rounded-full cursor-pointer"
                      title="Edit Category"
                    >
                      <span className="material-symbols-outlined text-[18px]">edit</span>
                    </button>
                    {categories.length > 1 && (
                      <button
                        onClick={() => onDeleteCategory(cat.id)}
                        className="p-2 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded-full animate-fadeIn cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-[18px]">delete</span>
                      </button>
                    )}
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-bold text-slate-800">{cat.name}</h3>
                  <div className="mt-2.5 inline-flex items-center px-2.5 py-1 bg-slate-100 text-slate-500 font-bold text-[10px] uppercase tracking-wider rounded-lg">
                    {cat.transactionCount} Transactions
                  </div>
                </div>
              </div>
            ))}

          {/* New category trigger mockup */}
          <button
            onClick={handleOpenAddCategory}
            className="group border-2 border-dashed border-slate-300 hover:border-indigo-500 bg-white/50 rounded-2xl p-5 flex flex-col items-center justify-center min-h-[160px] hover:bg-indigo-50/10 active:scale-95 transition-all outline-none cursor-pointer"
          >
            <span className="material-symbols-outlined text-slate-400 group-hover:text-indigo-650 group-hover:text-indigo-600 text-4xl mb-2">add_circle</span>
            <span className="text-xs font-bold text-slate-500 group-hover:text-indigo-600 tracking-wider uppercase">New Category</span>
          </button>
        </div>

        {/* Second advanced analytics block */}
        <section className="mt-14 grid grid-cols-1 md:grid-cols-2 gap-8 items-center border-t border-slate-205 border-slate-200 pt-10">
          <div className="bg-slate-900 rounded-2xl p-8 text-white relative overflow-hidden shadow-md">
            <div className="relative z-10">
              <h3 className="text-2xl font-extrabold mb-3 leading-tight text-white">Insights &amp; Flow</h3>
              <p className="text-sm leading-relaxed text-slate-300 mb-6 font-medium">
                Auto-categorization is currently active for 85% of your transactions. Adjust rules to improve accuracy.
              </p>
              <button className="bg-indigo-600 hover:bg-indigo-505 hover:bg-indigo-500 text-white font-bold text-xs uppercase tracking-wider px-6 py-3 rounded-full shadow-md cursor-pointer">
                Configure Rules
              </button>
            </div>
            {/* Visual glow */}
            <div className="absolute -right-20 -bottom-20 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl"></div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center gap-4 p-4 bg-white border border-slate-200 rounded-2xl hover:shadow-sm transition-all">
              <div className="w-12 h-12 rounded-full bg-slate-105 bg-slate-100 flex items-center justify-center text-indigo-600">
                <span className="material-symbols-outlined">auto_fix_high</span>
              </div>
              <div className="flex-grow">
                <h4 className="text-sm font-bold text-slate-800">Smart Sorting</h4>
                <p className="text-xs text-slate-400 font-semibold mt-0.5">Machine learning identifies recurring vendors.</p>
              </div>
              <div>
                <input
                  type="checkbox"
                  defaultChecked
                  className="rounded-full h-6 w-10 text-indigo-650 text-indigo-650 text-indigo-600 border-slate-350 focus:ring-indigo-500 cursor-pointer"
                />
              </div>
            </div>

            <div className="flex items-center gap-4 p-4 bg-white border border-slate-200 rounded-2xl hover:shadow-sm transition-all">
              <div className="w-12 h-12 rounded-full bg-slate-105 bg-slate-100 flex items-center justify-center text-indigo-600">
                <span className="material-symbols-outlined">archive</span>
              </div>
              <div className="flex-grow">
                <h4 className="text-sm font-bold text-slate-800">Archive Unused</h4>
                <p className="text-xs text-slate-400 font-semibold mt-0.5">Hide categories with no transactions for 6 months.</p>
              </div>
              <button className="text-indigo-600 hover:text-indigo-700 text-xs font-bold uppercase tracking-wider pr-1 cursor-pointer">
                Apply
              </button>
            </div>
          </div>
        </section>
      </main>

      {/* Pop up Modal interface */}
      {showModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-[#0b1c30]/40 backdrop-blur-sm" onClick={() => setShowModal(false)}></div>
          <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden animate-fadeIn">
            <div className="p-5 border-b border-slate-200 flex justify-between items-center">
              <h3 className="text-base font-bold text-slate-800">
                {editingCategoryId ? 'Edit Category' : 'Add New Category'}
              </h3>
              <button onClick={() => setShowModal(false)} className="p-2 hover:bg-slate-100 rounded-full text-slate-400 cursor-pointer">
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>
            <div className="p-5 space-y-5">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex flex-col gap-1.5 flex-2">
                  <label className="text-[10px] font-bold tracking-wider text-slate-500 uppercase">Category Name</label>
                  <input
                    type="text"
                    placeholder="e.g. Shopping"
                    value={newCatName}
                    onChange={(e) => setNewCatName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 outline-none font-medium text-sm text-slate-800"
                  />
                </div>
                <div className="flex flex-col gap-1.5 flex-1">
                  <label className="text-[10px] font-bold tracking-wider text-slate-500 uppercase">Tab / Type</label>
                  <select
                    value={newCatType}
                    onChange={(e) => setNewCatType(e.target.value as 'expense' | 'income')}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 outline-none font-medium text-sm text-slate-800 cursor-pointer"
                  >
                    <option value="expense">Expense</option>
                    <option value="income">Income</option>
                  </select>
                </div>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-bold tracking-wider text-slate-500 uppercase">Choose Icon</label>
                <div className="grid grid-cols-5 gap-2 h-44 overflow-y-auto p-1.5 bg-slate-50 rounded-xl border border-slate-100">
                  {[
                    'Home', 'ShoppingCart', 'Car', 'Utensils', 'Film', 'Zap', 'HeartPulse',
                    'Checkroom', 'Payments', 'ShowChart', 'Book', 'Flight', 'Work', 'Pets',
                    'Gift', 'Music', 'Coffee', 'Savings', 'MoreHorizontal'
                  ].map((sym) => (
                    <button
                      key={sym}
                      type="button"
                      onClick={() => setNewCatIcon(sym)}
                      className={`p-2.5 rounded-lg hover:bg-indigo-600 hover:text-white transition-all flex items-center justify-center cursor-pointer ${
                        newCatIcon === sym ? 'bg-indigo-600 text-white' : 'bg-slate-200/50 text-slate-600'
                      }`}
                      title={sym}
                    >
                      <span className="material-symbols-outlined text-[20px] font-bold">
                        {getMatSymbol(sym)}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-bold tracking-wider text-slate-500 uppercase">Color Accent</label>
                <div className="flex flex-wrap gap-2.5 justify-center bg-slate-50 p-3 rounded-xl border border-slate-100">
                  {[
                    '#6366f1', '#10b981', '#f43f5e', '#eab308', '#d946ef', '#a855f7',
                    '#06b6d4', '#3b82f6', '#f97316', '#14b8a6', '#84cc16', '#6b7280'
                  ].map((col) => (
                    <button
                      key={col}
                      type="button"
                      onClick={() => setNewCatColor(col)}
                      className={`w-8 h-8 rounded-full shadow-sm cursor-pointer transition-all ${
                        newCatColor === col ? 'ring-4 ring-offset-2 ring-indigo-600 scale-110' : ''
                      }`}
                      style={{ backgroundColor: col }}
                    ></button>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-5 bg-slate-50 flex gap-3">
              <button
                type="button"
                onClick={() => setShowModal(false)}
                className="flex-1 py-3 font-semibold text-xs uppercase tracking-wider text-slate-500 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveCategory}
                className="flex-2 bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 font-bold text-xs uppercase tracking-wider rounded-xl shadow-md cursor-pointer transition-all"
              >
                {editingCategoryId ? 'Save Changes' : 'Save Category'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Nav Spec Expected footer mapping links with icons dashboard/event_note/pie_chart */}
      <footer className="fixed bottom-0 left-0 w-full z-50 flex justify-around items-center px-4 py-2 bg-white border-t border-slate-200 shadow-lg rounded-t-2xl md:hidden">
        <a
          onClick={() => setScreen('EVENT_OVERVIEW')}
          className="flex flex-col items-center justify-center text-slate-500 hover:text-indigo-600 transition-all scale-95 hover:scale-105 active:scale-90 cursor-pointer py-1.5"
        >
          <span className="material-symbols-outlined">dashboard</span>
          <span className="text-[10px] font-semibold uppercase tracking-wider mt-0.5">Overview</span>
        </a>

        <a
          onClick={() => setScreen('MANAGE_EVENTS')}
          className="flex flex-col items-center justify-center text-slate-500 hover:text-indigo-600 transition-all scale-95 hover:scale-105 active:scale-90 cursor-pointer py-1.5"
        >
          <span className="material-symbols-outlined">event_note</span>
          <span className="text-[10px] font-semibold uppercase tracking-wider mt-0.5 font-sans">Events</span>
        </a>

        <a
          onClick={() => setScreen('YEARLY_SUMMARY')}
          className="flex flex-col items-center justify-center text-slate-500 hover:text-indigo-600 transition-all scale-95 hover:scale-105 active:scale-90 cursor-pointer py-1.5"
        >
          <span className="material-symbols-outlined">pie_chart</span>
          <span className="text-[10px] font-semibold uppercase tracking-wider mt-0.5">Budget</span>
        </a>
      </footer>
    </div>
  );
}
