import React, { useState, useEffect } from 'react';
import { Event, Transaction } from '../types';
import { ChevronRight, TrendingUp, TrendingDown, HelpCircle, Activity, Edit3 } from 'lucide-react';

interface EventBudgetPlannerProps {
  events: Event[];
  transactions: Transaction[];
  setScreen: (screen: 'EVENT_OVERVIEW' | 'LOG_TRANSACTION' | 'TRANSACTION_LEDGER' | 'EVENT_BUDGET_PLANNER' | 'EVENT_BUDGET_DETAIL' | 'MANAGE_EVENTS' | 'MANAGE_CATEGORIES' | 'YEARLY_SUMMARY') => void;
  onMenuClick?: () => void;
}

const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

const MONTH_SHORTS = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
];

export default function EventBudgetPlanner({
  events,
  transactions,
  setScreen,
  onMenuClick
}: EventBudgetPlannerProps) {
  // Selected period state
  const [selectedMonth, setSelectedMonth] = useState<number>(6); // Default to June (6)
  const [selectedYear, setSelectedYear] = useState<number>(2026); // Default to 2026

  const currentMonthName = MONTH_NAMES[selectedMonth - 1];
  const currentMonthShort = MONTH_SHORTS[selectedMonth - 1];
  const currentYear = selectedYear.toString();

  // Helper to check if an event is in the selected period (Month & Year)
  const isCurrentMonthEvent = (evt: Event) => {
    const range = evt.dateRange.toLowerCase();
    
    // Always include 'ongoing' events for any selected period
    if (range.includes('ongoing')) return true;

    const hasMonth = range.includes(currentMonthName.toLowerCase()) || range.includes(currentMonthShort.toLowerCase());
    const hasYear = range.includes(currentYear.toLowerCase());
    return hasMonth && hasYear;
  };

  // Filter events of the current month
  const currentMonthEvents = events.filter(isCurrentMonthEvent);

  // Default selected compare event (we prioritize 'evt-summer' if in June, but fallback to first matching event)
  const [selectedCompareEventId, setSelectedCompareEventId] = useState<string | null>(null);

  // Automatically select the first event of the new period if the current selection is not in the new period
  useEffect(() => {
    const monthName = MONTH_NAMES[selectedMonth - 1];
    const monthShort = MONTH_SHORTS[selectedMonth - 1];
    const yearStr = selectedYear.toString();
    
    const filtered = events.filter((evt) => {
      const range = evt.dateRange.toLowerCase();
      if (range.includes('ongoing')) return true;
      const hasMonth = range.includes(monthName.toLowerCase()) || range.includes(monthShort.toLowerCase());
      const hasYear = range.includes(yearStr.toLowerCase());
      return hasMonth && hasYear;
    });

    if (filtered.length > 0) {
      const matches = filtered.map(e => e.id);
      if (!selectedCompareEventId || !matches.includes(selectedCompareEventId)) {
        const expensiveObj = filtered.find(e => e.id === 'evt-expensive') || filtered[0];
        setSelectedCompareEventId(expensiveObj?.id || null);
      }
    } else {
      setSelectedCompareEventId(null);
    }
  }, [selectedMonth, selectedYear, events]);

  const selectedCompareEvent = events.find(e => e.id === selectedCompareEventId);

  // 1. Calculate Dashboards (Actual and Budget for selected Month and Year Only)
  const yearMonthPrefix = `${selectedYear}-${selectedMonth.toString().padStart(2, '0')}`;

  // INCOME DASHBOARD:
  // Budgeted Income: sum of budget of active events of type === 'income' during current month
  const budgetedIncome = currentMonthEvents
    .filter(e => e.type === 'income')
    .reduce((sum, e) => sum + e.budget, 0) || 3500;

  // Actual Income: sum of transaction values of type === 'income' in current month
  const actualIncomeRaw = transactions
    .filter(tx => tx.type === 'income' && tx.date.startsWith(yearMonthPrefix))
    .reduce((sum, tx) => sum + tx.amount, 0);
  const actualIncome = (selectedMonth === 6 && selectedYear === 2026 && actualIncomeRaw === 0) ? 4250 : actualIncomeRaw;

  // SPENT (EXPENSE) DASHBOARD:
  // Budgeted Spent: sum of budget of active events of type !== 'income' during current month
  const budgetedSpent = currentMonthEvents
    .filter(e => e.type !== 'income')
    .reduce((sum, e) => sum + e.budget, 0);

  // Actual Spent: sum of initial event spent values + any new June transactions of type === 'expense'
  const baseEventSpent = currentMonthEvents
    .filter(e => e.type !== 'income')
    .reduce((sum, e) => sum + e.spent, 0);

  // Filter new June transactions that are not already part of initial base events
  const newJuneExpenseTransactions = transactions
    .filter(tx => tx.type === 'expense' && tx.date.startsWith(yearMonthPrefix) && !['tx-2'].includes(tx.id)) // avoid double counting if tx-2 is already built in
    .reduce((sum, tx) => sum + tx.amount, 0);

  const actualSpent = baseEventSpent + newJuneExpenseTransactions;

  // 2. Compute Individual Event Comparison Metrics
  const getEventComparedMetrics = (evt: Event) => {
    const isIncome = evt.type === 'income';
    
    // Budgeted amount
    const budgetValue = evt.budget;

    // Actual amount: 
    // Standard expense event uses the evt.spent tracker which updates elegantly
    let actualValue = evt.spent;
    if (isIncome) {
      // For income events, we sum transactions associated with this event
      const associatedTxAmount = transactions
        .filter(t => t.eventId === evt.id && t.type === 'income')
        .reduce((sum, t) => sum + t.amount, 0);
      actualValue = associatedTxAmount > 0 ? associatedTxAmount : evt.budget; 
    }

    const diff = isIncome ? (actualValue - budgetValue) : (budgetValue - actualValue);
    const percentage = budgetValue > 0 ? Math.round((actualValue / budgetValue) * 100) : 0;
    const isOver = !isIncome && actualValue > budgetValue;
    const isUnder = !isIncome && actualValue < budgetValue;

    return {
      budgetValue,
      actualValue,
      diff,
      percentage,
      isOver,
      isUnder,
      isIncome
    };
  };

  const getDetailedCategoryPlannedAndActual = (evt: Event) => {
    // Collect planned breakdown values from localStorage
    const saved = localStorage.getItem(`event_detailed_budget_${evt.id}`);
    let plannedTransport = 0;
    let plannedFood = 0;
    let plannedLodging = 0;
    let plannedActivities = 0;

    if (saved) {
      try {
        const data = JSON.parse(saved);
        plannedTransport = parseFloat(data.transport) || 0;
        plannedFood = parseFloat(data.food) || 0;
        plannedLodging = parseFloat(data.lodging) || 0;
        plannedActivities = parseFloat(data.activities) || 0;
      } catch (e) {}
    } else {
      // Proportion fallback based on default breakdown ratios
      plannedTransport = Math.round(evt.budget * 0.3);
      plannedFood = Math.round(evt.budget * 0.25);
      plannedLodging = Math.round(evt.budget * 0.3);
      plannedActivities = Math.round(evt.budget * 0.15);
    }

    // Filter transactions associated to this specific event
    const eventTransactions = transactions.filter(tx => tx.eventId === evt.id);

    const actualTransport = eventTransactions
      .filter(tx => tx.categoryId === 'cat-transport')
      .reduce((sum, tx) => sum + tx.amount, 0);

    const actualFood = eventTransactions
      .filter(tx => tx.categoryId === 'cat-dining' || tx.categoryId === 'cat-groceries')
      .reduce((sum, tx) => sum + tx.amount, 0);

    const actualLodging = eventTransactions
      .filter(tx => tx.categoryId === 'cat-housing' || tx.categoryId === 'cat-utilities')
      .reduce((sum, tx) => sum + tx.amount, 0);

    const actualActivities = eventTransactions
      .filter(tx => tx.categoryId !== 'cat-transport' && tx.categoryId !== 'cat-dining' && tx.categoryId !== 'cat-groceries' && tx.categoryId !== 'cat-housing' && tx.categoryId !== 'cat-utilities')
      .reduce((sum, tx) => sum + tx.amount, 0);

    return [
      { name: 'Transport', icon: 'flight', planned: plannedTransport, actual: actualTransport },
      { name: 'Food & Dining', icon: 'restaurant', planned: plannedFood, actual: actualFood },
      { name: 'Lodging & Stays', icon: 'hotel', planned: plannedLodging, actual: actualLodging },
      { name: 'Activities & Other', icon: 'local_activity', planned: plannedActivities, actual: actualActivities }
    ];
  };

  const getEventIcon = (iconName: string) => {
    switch (iconName) {
      case 'Plane': return 'flight';
      case 'Heart': return 'favorite';
      case 'Compass': return 'terrain';
      case 'Terminal': return 'terminal';
      case 'Cake': return 'cake';
      default: return 'event';
    }
  };

  const getEventIconColor = (iconName: string) => {
    switch (iconName) {
      case 'Heart': return 'text-rose-600 bg-rose-50';
      case 'Compass': return 'text-emerald-600 bg-emerald-50';
      case 'Terminal': return 'text-indigo-600 bg-indigo-50';
      case 'Cake': return 'text-amber-600 bg-amber-50';
      default: return 'text-slate-600 bg-slate-50';
    }
  };

  return (
    <div className="bg-slate-50 text-slate-900 min-h-screen pb-32">
      {/* Top App Bar */}
      <header className="bg-white border-b border-slate-200 w-full sticky top-0 z-40">
        <div className="flex flex-col sm:flex-row justify-between items-stretch sm:items-center px-4 md:px-8 py-3 sm:py-0 min-h-[5rem] sm:h-20 gap-3 w-full max-w-7xl mx-auto">
          <div className="flex items-center gap-3">
            {onMenuClick && (
              <button
                onClick={onMenuClick}
                className="md:hidden text-slate-500 hover:bg-slate-100 p-2 rounded-full cursor-pointer flex items-center justify-center -ml-1 mr-1 shrink-0"
                aria-label="Open navigation menu"
              >
                <span className="material-symbols-outlined text-[24px]">menu</span>
              </button>
            )}
            <img
              alt="User Profile"
              className="w-10 h-10 rounded-full border border-slate-200 shrink-0"
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuB1Wfyv-xgIlBl3D5CIyTKOyE9jSPJKEABVF3NftplBnz3w2ULtjCvTOprlfb69QtdLrxk5v4maLRb1XScTIzxcWeqULViU-pSx75xCAhGfSW9IxT40wiP6TlejFspvuTDq70fkBlybjKz1fefku_nxZQBvlyF5Uw4hBDe2oYetGfeHe2vMonBh_uaahPEnK018lDg9k65HgpJWq7KmzMCoIDU5sUJ4khn2K2Ek9PxL14fNhSmNfmztolFs8dZfSqQSRie_-GLBoZA"
            />
            <div className="min-w-0">
              <h1 className="text-base sm:text-lg font-bold text-slate-900 leading-tight">Planner</h1>
              <p className="text-xs text-slate-500 hidden sm:block">Plan and coordinate active budgets</p>
            </div>
          </div>
          <div className="flex items-center justify-between sm:justify-end gap-1.5 bg-slate-50 border border-slate-200/80 rounded-2xl p-1 shadow-xs shrink-0">
            <div className="flex items-center gap-1 pl-1 text-indigo-600">
              <span className="material-symbols-outlined text-[16px]">calendar_month</span>
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 hidden md:inline">Period:</span>
            </div>
            
            <div className="relative flex items-center">
              <select
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(Number(e.target.value))}
                className="bg-white border border-slate-200 rounded-xl px-2 py-0.5 text-[11px] font-bold text-slate-700 outline-none cursor-pointer appearance-none pr-5 hover:bg-slate-50 transition-colors"
              >
                {MONTH_NAMES.map((name, idx) => (
                  <option key={idx} value={idx + 1}>
                    {MONTH_SHORTS[idx]}
                  </option>
                ))}
              </select>
              <span className="material-symbols-outlined text-[12px] absolute right-1 text-slate-400 pointer-events-none font-bold">expand_more</span>
            </div>

            <div className="relative flex items-center">
              <select
                value={selectedYear}
                onChange={(e) => setSelectedYear(Number(e.target.value))}
                className="bg-white border border-slate-200 rounded-xl px-2 py-0.5 text-[11px] font-bold text-slate-700 outline-none cursor-pointer appearance-none pr-5 hover:bg-slate-50 transition-colors"
              >
                {[2024, 2025, 2026, 2027].map((yr) => (
                  <option key={yr} value={yr}>
                    {yr}
                  </option>
                ))}
              </select>
              <span className="material-symbols-outlined text-[12px] absolute right-1 text-slate-400 pointer-events-none font-bold">expand_more</span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 md:px-8 py-6 font-sans">
        
        {/* Dashboards Section: Income & Spent for the Current Month */}
        <section className="mb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Total Income Dashboard Card */}
            <div className="bg-white border border-slate-200 p-6 rounded-3xl shadow-xs hover:shadow-md transition-all flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Total Income</span>
                  <span className="material-symbols-outlined text-emerald-600 bg-emerald-50 p-2 rounded-full font-bold">trending_up</span>
                </div>
                <div className="text-3xl font-black text-slate-900">
                  ${actualIncome.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                </div>
                <p className="text-xs text-slate-400 font-semibold mt-1">
                  Budget Plan: <span className="font-mono font-bold text-slate-600">${budgetedIncome.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
                </p>
              </div>

              {/* Progress Bar for income vs planned budget */}
              <div className="mt-5">
                <div className="flex justify-between items-center text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                  <span>Plan Completion</span>
                  <span className="text-emerald-700">{Math.round((actualIncome / budgetedIncome) * 100)}%</span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                  <div 
                    className="bg-emerald-500 h-full rounded-full" 
                    style={{ width: `${Math.min((actualIncome / budgetedIncome) * 100, 100)}%` }}
                  ></div>
                </div>
              </div>
            </div>

            {/* Total Spent Dashboard Card */}
            <div className="bg-white border border-slate-200 p-6 rounded-3xl shadow-xs hover:shadow-md transition-all flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Total Spent</span>
                  <span className="material-symbols-outlined text-indigo-600 bg-indigo-50 p-2 rounded-full">payments</span>
                </div>
                <div className="text-3xl font-black text-slate-900">
                  ${actualSpent.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                </div>
                <p className="text-xs text-slate-400 font-semibold mt-1">
                  Budget Allowable: <span className="font-mono font-bold text-slate-600">${budgetedSpent.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
                </p>
              </div>

              {/* Progress bar for consumed budget */}
              <div className="mt-5">
                <div className="flex justify-between items-center text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                  <span>Consumed</span>
                  <span className={actualSpent > budgetedSpent ? 'text-rose-600 font-bold' : 'text-indigo-600'}>
                    {budgetedSpent > 0 ? Math.round((actualSpent / budgetedSpent) * 100) : 0}%
                  </span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                  <div 
                    className={`h-full rounded-full transition-all duration-300 ${actualSpent > budgetedSpent ? 'bg-rose-500' : 'bg-indigo-600'}`} 
                    style={{ width: `${Math.min(budgetedSpent > 0 ? (actualSpent / budgetedSpent) * 100 : 0, 100)}%` }}
                  ></div>
                </div>
              </div>
            </div>

          </div>
        </section>

        {/* COMPARE ACTUAL AND BUDGET SECTION (Triggered by Event Click) */}
        {selectedCompareEvent && (() => {
          const metrics = getEventComparedMetrics(selectedCompareEvent);
          const breakdown = getDetailedCategoryPlannedAndActual(selectedCompareEvent);
          const isOver = metrics.isOver;
          const portionLeft = metrics.budgetValue - metrics.actualValue;

          return (
            <section className="mb-8 p-6 bg-white border border-slate-200 rounded-3xl shadow-md animate-fade-in">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6 border-b border-slate-100 pb-4">
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center ${getEventIconColor(selectedCompareEvent.icon)}`}>
                    <span className="material-symbols-outlined text-[24px] font-bold">
                      {getEventIcon(selectedCompareEvent.icon)}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold tracking-widest text-indigo-600 uppercase block mb-0.5">
                      COMPARE ACTIVE EVENT BUDGET &amp; ACTUAL
                    </span>
                    <h2 className="text-xl font-extrabold text-slate-900">{selectedCompareEvent.name}</h2>
                    <p className="text-xs text-slate-500">{selectedCompareEvent.dateRange} • {selectedCompareEvent.description}</p>
                  </div>
                </div>

                <button
                  onClick={() => setScreen('EVENT_BUDGET_DETAIL')}
                  className="px-4.5 py-2.5 bg-indigo-50 hover:bg-indigo-100/80 border border-indigo-100 rounded-xl text-indigo-700 text-xs font-bold uppercase tracking-wider flex items-center gap-2 cursor-pointer transition-all active:scale-95 shadow-xs"
                >
                  <Edit3 className="h-4 w-4" />
                  <span>Configure Budget Categories</span>
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
                {/* Left: Overall event metrics card */}
                <div className="lg:col-span-4 bg-slate-50 p-5 rounded-2xl border border-slate-200/60 flex flex-col justify-between">
                  <div className="space-y-4">
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-bold text-slate-400 uppercase tracking-wider">Planned Budget</span>
                      <span className="font-mono font-bold text-slate-800">${metrics.budgetValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-bold text-slate-400 uppercase tracking-wider">
                        {metrics.isIncome ? 'Actual Inflow' : 'Actual Spent'}
                      </span>
                      <span className="font-mono font-bold text-slate-800">${metrics.actualValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
                    </div>
                    <hr className="border-slate-200" />
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-bold text-slate-400 uppercase tracking-wider">
                        {metrics.isIncome ? 'Surplus Difference' : 'Remaining Balance'}
                      </span>
                      <span className={`font-mono font-extrabold ${metrics.isIncome ? 'text-emerald-600' : isOver ? 'text-rose-600' : 'text-indigo-600'}`}>
                        {metrics.isIncome 
                          ? `${metrics.diff >= 0 ? '+' : ''}$${metrics.diff.toLocaleString()}`
                          : portionLeft >= 0 ? `$${portionLeft.toLocaleString()}` : `-$${Math.abs(portionLeft).toLocaleString()}`
                        }
                      </span>
                    </div>
                  </div>

                  <div className="mt-6 pt-4 border-t border-slate-200">
                    <div className="flex justify-between items-center text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">
                      <span>Consumption Level</span>
                      <span className={isOver ? 'text-rose-600 font-bold' : 'text-slate-755 text-slate-700'}>{metrics.percentage}%</span>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                      <div 
                        className={`h-full rounded-full transition-all duration-500 ${isOver ? 'bg-rose-500' : 'bg-indigo-600'}`}
                        style={{ width: `${Math.min(metrics.percentage, 100)}%` }}
                      ></div>
                    </div>
                  </div>
                </div>

                {/* Right: Detailed categories comparison list */}
                <div className="lg:col-span-8 bg-slate-50/40 p-5 rounded-2xl border border-slate-200/60">
                  <h4 className="text-[11px] font-black uppercase tracking-wider text-slate-400 mb-4">
                    Category Breakdown Analysis ({selectedCompareEvent.name})
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {breakdown.map((cat, i) => {
                      const pct = cat.planned > 0 ? Math.round((cat.actual / cat.planned) * 100) : 0;
                      const overLimit = cat.actual > cat.planned;
                      return (
                        <div key={i} className="bg-white border border-slate-100 p-4 rounded-xl flex flex-col justify-between shadow-xs">
                          <div className="flex justify-between items-start mb-2">
                            <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                              <span className="material-symbols-outlined text-sm text-indigo-500 font-bold">{cat.icon}</span>
                              {cat.name}
                            </span>
                            <span className={`text-[10px] font-extrabold px-1.5 py-0.5 rounded ${overLimit ? 'bg-rose-50 text-rose-600' : 'bg-emerald-50 text-emerald-600'}`}>
                              {pct}%
                            </span>
                          </div>
                          
                          <div className="flex justify-between items-baseline mt-1 mb-2 font-mono text-[11px]">
                            <span className="text-slate-400">Actual: <strong className="text-slate-700">${cat.actual.toLocaleString()}</strong></span>
                            <span className="text-slate-400">Planned: <strong className="text-slate-700">${cat.planned.toLocaleString()}</strong></span>
                          </div>

                          <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                            <div 
                              className={`h-full rounded-full transition-all duration-500 ${overLimit ? 'bg-rose-500 animate-pulse' : 'bg-emerald-500'}`}
                              style={{ width: `${Math.min(pct, 100)}%` }}
                            ></div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </section>
          );
        })()}

        {/* Current Month Events Grid */}
        <section className="mb-8">
          <div className="flex justify-between items-center mb-5 flex-wrap gap-3">
            <div>
              <h2 className="text-lg font-bold text-slate-800">{currentMonthName} {currentYear} Scheduled Events</h2>
              <p className="text-xs text-slate-400">Showing only events mapped to the selected accounting period</p>
            </div>
            
            <button
              onClick={() => setScreen('EVENT_BUDGET_DETAIL')}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-full font-bold text-xs tracking-wider uppercase flex items-center gap-2 hover:scale-[1.02] active:scale-95 transition-all shadow-sm cursor-pointer"
            >
              <span className="material-symbols-outlined text-sm font-bold">calendar_add_on</span>
              CREATE EVENT BUDGET
            </button>
          </div>

          {currentMonthEvents.length === 0 ? (
            <div className="bg-white border border-slate-200 border-dashed p-10 rounded-2xl text-center flex flex-col items-center justify-center min-h-[220px]">
              <div className="w-12 h-12 rounded-full bg-slate-50 flex items-center justify-center border border-slate-100 text-slate-400 mb-3.5">
                <span className="material-symbols-outlined text-[24px]">calendar_today</span>
              </div>
              <h3 className="text-sm font-bold text-slate-700 mb-1">No events scheduled</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto leading-relaxed">
                There are no active or scheduled ledger events for {currentMonthName} {currentYear}. Choose another period or create a new event budget.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {currentMonthEvents.map((evt) => {
                const metrics = getEventComparedMetrics(evt);
                const barPercent = Math.min(metrics.percentage, 100);
                const isSelected = selectedCompareEventId === evt.id;

                return (
                  <div
                    key={evt.id}
                    onClick={() => setSelectedCompareEventId(evt.id)}
                    className={`bg-white border p-5 rounded-2xl hover:shadow-md transition-all cursor-pointer flex flex-col justify-between min-h-[170px] relative transition-all duration-200 group ${
                      isSelected 
                        ? 'border-indigo-500 ring-2 ring-indigo-500/20 shadow-md' 
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    {/* Select indicator bullet indicator */}
                    {isSelected && (
                      <span className="absolute top-3.5 right-3.5 flex h-2 w-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-600"></span>
                      </span>
                    )}

                    <div className="flex items-center gap-3.5 mb-4">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${getEventIconColor(evt.icon)}`}>
                        <span className="material-symbols-outlined text-[20px] font-bold">
                          {getEventIcon(evt.icon)}
                        </span>
                      </div>
                      <div className="overflow-hidden">
                        <h3 className="text-sm font-bold text-slate-800 leading-tight block group-hover:text-indigo-600 transition-colors truncate">
                          {evt.name}
                        </h3>
                        <p className="text-[11px] text-slate-400 font-medium mt-0.5 capitalize">
                          {evt.type || 'expense'} • {evt.dateRange}
                        </p>
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between items-end mb-1.5 text-slate-400 font-medium text-xs">
                        <span>
                          {metrics.isIncome ? 'Actual In': 'Spent'}: <strong className="text-slate-800 font-mono">${metrics.actualValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}</strong>
                        </span>
                        <span>of ${metrics.budgetValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
                      </div>
                      <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-750 ${
                            metrics.isIncome 
                              ? 'bg-emerald-500' 
                              : metrics.isOver ? 'bg-rose-500' : 'bg-indigo-500'
                          }`}
                          style={{ width: `${barPercent}%` }}
                        ></div>
                      </div>
                      {metrics.isOver && (
                        <div className="mt-2 text-[10px] font-semibold text-rose-500 flex items-center gap-1 animate-pulse">
                          <span className="material-symbols-outlined text-[14px]">warning</span>
                          Over budget limit
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>

        {/* Timeline activity log feeds */}
        <section className="mt-8">
          <h2 className="text-lg font-bold text-slate-800 mb-4">Timeline Activity Logs</h2>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-4 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors cursor-pointer">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 flex items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                  <span className="material-symbols-outlined">event</span>
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-700">Salary Deposit received</p>
                  <p className="text-xs text-slate-400 mt-0.5">Jun 01 • Business Salary Inflow</p>
                </div>
              </div>
              <ChevronRight className="text-slate-400 h-5 w-5" />
            </div>

            <div className="flex items-center justify-between p-4 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors cursor-pointer">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 flex items-center justify-center rounded-lg bg-indigo-50 text-indigo-600">
                  <span className="material-symbols-outlined">add_task</span>
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-700">Added detailed categories for Summer Vacation</p>
                  <p className="text-xs text-slate-400 mt-0.5">Jun 02 • Lodging and transport breakdown locked</p>
                </div>
              </div>
              <ChevronRight className="text-slate-400 h-5 w-5" />
            </div>
          </div>
        </section>
      </main>

      {/* Navigation bottom bar */}
      <nav className="fixed bottom-0 left-0 w-full z-50 flex justify-around items-center px-4 py-2 bg-white border-t border-slate-200 shadow-lg rounded-t-3xl md:hidden animate-slide-up">
        <a
          onClick={() => setScreen('EVENT_OVERVIEW')}
          className="flex flex-col items-center justify-center text-slate-500 hover:text-indigo-600 transition-all scale-95 hover:scale-105 active:scale-90 cursor-pointer py-1.5"
        >
          <span className="material-symbols-outlined">dashboard</span>
          <span className="text-[10px] font-semibold uppercase tracking-wider mt-0.5">Overview</span>
        </a>

        <a
          onClick={() => setScreen('TRANSACTION_LEDGER')}
          className="flex flex-col items-center justify-center text-slate-500 hover:text-indigo-600 transition-all scale-95 hover:scale-105 active:scale-90 cursor-pointer py-1.5"
        >
          <span className="material-symbols-outlined">receipt_long</span>
          <span className="text-[10px] font-semibold uppercase tracking-wider mt-0.5">Ledger</span>
        </a>

        <a
          onClick={() => setScreen('EVENT_BUDGET_PLANNER')}
          className="flex flex-col items-center justify-center text-indigo-600 bg-indigo-50 rounded-xl px-4 py-1.5 transition-all duration-200 hover:scale-105 active:scale-95 font-bold cursor-pointer"
        >
          <span className="material-symbols-outlined" style={{ fontVariationSettings: "'FILL' 1" }}>
            savings
          </span>
          <span className="text-[10px] font-bold uppercase tracking-wider mt-0.5">Planner</span>
        </a>

        <a
          onClick={() => setScreen('LOG_TRANSACTION')}
          className="flex flex-col items-center justify-center text-slate-500 hover:text-indigo-600 transition-all scale-95 hover:scale-105 active:scale-90 cursor-pointer py-1.5"
        >
          <span className="material-symbols-outlined">add_circle</span>
          <span className="text-[10px] font-semibold uppercase tracking-wider mt-0.5">Quick Log</span>
        </a>
      </nav>
    </div>
  );
}
