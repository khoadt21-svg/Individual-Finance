import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Event, Category, Transaction, ScreenType } from './types';
import {
  INITIAL_EVENTS,
  INITIAL_CATEGORIES,
  INITIAL_TRANSACTIONS,
  loadData,
  saveData
} from './data';

import EventOverview from './components/EventOverview';
import LogTransaction from './components/LogTransaction';
import TransactionLedger from './components/TransactionLedger';
import EventBudgetPlanner from './components/EventBudgetPlanner';
import EventBudgetDetail from './components/EventBudgetDetail';
import ManageEvents from './components/ManageEvents';
import ManageCategories from './components/ManageCategories';
import YearlySummary from './components/YearlySummary';
import Sidebar from './components/Sidebar';

export default function App() {
  // Global States
  const [events, setEvents] = useState<Event[]>(() => {
    const loaded = loadData<Event[]>('events', INITIAL_EVENTS);
    if (loaded && loaded.length > 0 && !loaded.some(e => e.type !== undefined)) {
      return INITIAL_EVENTS;
    }
    return loaded;
  });
  const [categories, setCategories] = useState<Category[]>(() => loadData<Category[]>('categories', INITIAL_CATEGORIES));
  const [transactions, setTransactions] = useState<Transaction[]>(() => loadData<Transaction[]>('transactions', INITIAL_TRANSACTIONS));
  
  // Shared period filter states (Default to June 2026)
  const [selectedMonth, setSelectedMonth] = useState<number>(6);
  const [selectedYear, setSelectedYear] = useState<number>(2026);
  
  // Screen and Transition state
  const [screen, setScreenState] = useState<ScreenType>('EVENT_OVERVIEW');
  const [transition, setTransition] = useState<'none' | 'push' | 'push_back' | 'slide_up'>('none');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Persistence triggers
  useEffect(() => {
    saveData('events', events);
  }, [events]);

  useEffect(() => {
    saveData('categories', categories);
  }, [categories]);

  useEffect(() => {
    saveData('transactions', transactions);
  }, [transactions]);

  // Navigate helper to enforce exact specified transitions
  const navigate = (
    toScreen: ScreenType,
    mode: 'none' | 'push' | 'push_back' | 'slide_up' = 'none'
  ) => {
    setTransition(mode);
    setScreenState(toScreen);
  };

  // Transaction Save Action
  const handleSaveTransaction = (newTx: Omit<Transaction, 'id'>) => {
    const tx: Transaction = {
      ...newTx,
      id: `tx-${Date.now()}`
    };
    
    // Update transactions list
    setTransactions((prev) => [tx, ...prev]);

    // Side effects: increment categories transaction counts
    setCategories((prev) =>
      prev.map((c) =>
        c.id === tx.categoryId
          ? { ...c, transactionCount: c.transactionCount + 1 }
          : c
      )
    );

    // Side effects: increment associated events budget spent values
    setEvents((prev) =>
      prev.map((e) =>
        e.id === tx.eventId && tx.type === 'expense'
          ? { ...e, spent: e.spent + tx.amount }
          : e
      )
    );
  };

  // Transaction Edit Action
  const handleEditTransaction = (id: string, updatedTx: Omit<Transaction, 'id'>) => {
    const oldTx = transactions.find((t) => t.id === id);
    if (!oldTx) return;

    // Update transactions list
    setTransactions((prev) =>
      prev.map((t) => (t.id === id ? { ...t, ...updatedTx } : t))
    );

    // Revert old effects, apply new effects
    setCategories((prev) =>
      prev.map((c) => {
        let count = c.transactionCount;
        if (c.id === oldTx.categoryId) count = Math.max(0, count - 1);
        if (c.id === updatedTx.categoryId) count = count + 1;
        return { ...c, transactionCount: count };
      })
    );

    setEvents((prev) =>
      prev.map((e) => {
        let spent = e.spent;
        if (e.id === oldTx.eventId && oldTx.type === 'expense') {
          spent = Math.max(0, spent - oldTx.amount);
        }
        if (e.id === updatedTx.eventId && updatedTx.type === 'expense') {
          spent = spent + updatedTx.amount;
        }
        return { ...e, spent };
      })
    );
  };

  // Transaction Delete Action
  const handleDeleteTransaction = (id: string) => {
    const tx = transactions.find((t) => t.id === id);
    if (!tx) return;

    setTransactions((prev) => prev.filter((t) => t.id !== id));

    setCategories((prev) =>
      prev.map((c) =>
        c.id === tx.categoryId
          ? { ...c, transactionCount: Math.max(0, c.transactionCount - 1) }
          : c
      )
    );

    setEvents((prev) =>
      prev.map((e) =>
        e.id === tx.eventId && tx.type === 'expense'
          ? { ...e, spent: Math.max(0, e.spent - tx.amount) }
          : e
      )
    );
  };

  // Event creation
  const handleAddEvent = (newEvent: Omit<Event, 'id'>) => {
    const evt: Event = {
      ...newEvent,
      id: `evt-${Date.now()}`
    };
    setEvents((prev) => [...prev, evt]);
  };

  // Event editing
  const handleEditEvent = (id: string, updatedEvent: Omit<Event, 'id'>) => {
    setEvents((prev) =>
      prev.map((e) => (e.id === id ? { ...e, ...updatedEvent } : e))
    );
  };

  // Event deletion
  const handleDeleteEvent = (id: string) => {
    setEvents((prev) => prev.filter((e) => e.id !== id));
  };

  // Category creation
  const handleAddCategory = (newCat: Omit<Category, 'id' | 'transactionCount'>) => {
    const cat: Category = {
      ...newCat,
      id: `cat-${Date.now()}`,
      transactionCount: 0
    };
    setCategories((prev) => [...prev, cat]);
  };

  // Category editing
  const handleEditCategory = (id: string, updatedFields: Omit<Category, 'id' | 'transactionCount'>) => {
    setCategories((prev) =>
      prev.map((c) => (c.id === id ? { ...c, ...updatedFields } : c))
    );
  };

  // Category deletion
  const handleDeleteCategory = (id: string) => {
    setCategories((prev) => prev.filter((c) => c.id !== id));
  };

  // Event Budget Detail values saving
  const handleSaveDetailBudget = (totalBudgetAmount: number) => {
    setEvents((prev) =>
      prev.map((e) =>
        e.id === 'evt-summer'
          ? { ...e, budget: totalBudgetAmount }
          : e
      )
    );
  };

  // Find active / upcoming events
  const activeEvent = events.find((e) => e.id === 'evt-summer') || events[0];
  const nextEvent = events.find((e) => e.id === 'evt-holiday') || events[1];

  // Animation Variant definitions based on strict spec guidelines
  const animationVariants = {
    none: {
      initial: { opacity: 0 },
      animate: { opacity: 1 },
      exit: { opacity: 0 },
      transition: { duration: 0 }
    },
    push: {
      initial: { opacity: 0, x: 100 },
      animate: { opacity: 1, x: 0 },
      exit: { opacity: 0, x: -100 },
      transition: { type: 'spring', stiffness: 260, damping: 26 }
    },
    push_back: {
      initial: { opacity: 0, x: -100 },
      animate: { opacity: 1, x: 0 },
      exit: { opacity: 0, x: 100 },
      transition: { type: 'spring', stiffness: 260, damping: 26 }
    },
    slide_up: {
      initial: { opacity: 0, y: 150 },
      animate: { opacity: 1, y: 0 },
      exit: { opacity: 0, y: -150 },
      transition: { type: 'spring', stiffness: 300, damping: 30 }
    }
  };

  return (
    <div className="relative flex min-h-screen bg-slate-50 text-slate-900 font-sans">
      {/* Sidebar Navigation */}
      <Sidebar
        currentScreen={screen}
        onNavigate={(s) => navigate(s, 'none')}
        isOpenMobile={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-h-screen overflow-x-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={screen}
            initial="initial"
            animate="animate"
            exit="exit"
            variants={animationVariants[transition]}
            className="flex-1 w-full relative"
          >
            {screen === 'EVENT_OVERVIEW' && (
              <EventOverview
                events={events}
                activeEvent={activeEvent}
                nextEvent={nextEvent}
                transactions={transactions}
                categories={categories}
                selectedMonth={selectedMonth}
                setSelectedMonth={setSelectedMonth}
                selectedYear={selectedYear}
                setSelectedYear={setSelectedYear}
                setScreen={(s) => {
                  if (s === 'LOG_TRANSACTION') navigate(s, 'slide_up');
                  else navigate(s, 'none');
                }}
                onMenuClick={() => setMobileMenuOpen(true)}
              />
            )}

            {screen === 'LOG_TRANSACTION' && (
              <LogTransaction
                events={events}
                categories={categories}
                onSave={handleSaveTransaction}
                setScreen={(s) => {
                  if (s === 'TRANSACTION_LEDGER') navigate(s, 'push_back');
                  else navigate(s, 'none');
                }}
              />
            )}

            {screen === 'TRANSACTION_LEDGER' && (
              <TransactionLedger
                transactions={transactions}
                categories={categories}
                events={events}
                selectedMonth={selectedMonth}
                setSelectedMonth={setSelectedMonth}
                selectedYear={selectedYear}
                setSelectedYear={setSelectedYear}
                onEditTransaction={handleEditTransaction}
                onDeleteTransaction={handleDeleteTransaction}
                setScreen={(s) => {
                  if (s === 'LOG_TRANSACTION') navigate(s, 'slide_up');
                  else navigate(s, 'none');
                }}
                onMenuClick={() => setMobileMenuOpen(true)}
              />
            )}

            {screen === 'EVENT_BUDGET_PLANNER' && (
              <EventBudgetPlanner
                events={events}
                transactions={transactions}
                setScreen={(s) => {
                  if (s === 'EVENT_BUDGET_DETAIL') navigate(s, 'push');
                  else navigate(s, 'none');
                }}
                onMenuClick={() => setMobileMenuOpen(true)}
              />
            )}

            {screen === 'EVENT_BUDGET_DETAIL' && (
              <EventBudgetDetail
                events={events}
                onSave={(eventId, totalBudgetAmount) => {
                  setEvents((prev) =>
                    prev.map((e) =>
                      e.id === eventId
                        ? { ...e, budget: totalBudgetAmount }
                        : e
                    )
                  );
                }}
                setScreen={(s) => {
                  if (s === 'EVENT_BUDGET_PLANNER') navigate(s, 'push_back');
                  else navigate(s, 'none');
                }}
              />
            )}

            {screen === 'MANAGE_EVENTS' && (
              <ManageEvents
                events={events}
                onAddEvent={handleAddEvent}
                onEditEvent={handleEditEvent}
                onDeleteEvent={handleDeleteEvent}
                setScreen={(s) => navigate(s, 'none')}
                onMenuClick={() => setMobileMenuOpen(true)}
              />
            )}

            {screen === 'MANAGE_CATEGORIES' && (
              <ManageCategories
                categories={categories}
                onAddCategory={handleAddCategory}
                onDeleteCategory={handleDeleteCategory}
                onEditCategory={handleEditCategory}
                setScreen={(s) => navigate(s, 'none')}
                onMenuClick={() => setMobileMenuOpen(true)}
              />
            )}

            {screen === 'YEARLY_SUMMARY' && (
              <YearlySummary
                events={events}
                setScreen={(s) => {
                  if (s === 'MANAGE_CATEGORIES') navigate(s, 'push');
                  else navigate(s, 'none');
                }}
                onMenuClick={() => setMobileMenuOpen(true)}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
