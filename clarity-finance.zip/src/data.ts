import { Event, Category, Transaction } from './types';

export const INITIAL_CATEGORIES: Category[] = [
  { id: 'cat-housing', name: 'Housing', type: 'expense', icon: 'Home', color: '#3b82f6', transactionCount: 6 },
  { id: 'cat-groceries', name: 'Groceries', type: 'expense', icon: 'ShoppingCart', color: '#10b981', transactionCount: 24 },
  { id: 'cat-transport', name: 'Transport', type: 'expense', icon: 'Car', color: '#ef4444', transactionCount: 12 },
  { id: 'cat-dining', name: 'Dining', type: 'expense', icon: 'Utensils', color: '#f59e0b', transactionCount: 15 },
  { id: 'cat-entertainment', name: 'Entertainment', type: 'expense', icon: 'Film', color: '#8b5cf6', transactionCount: 8 },
  { id: 'cat-utilities', name: 'Utilities', type: 'expense', icon: 'Zap', color: '#06b6d4', transactionCount: 4 },
  { id: 'cat-health', name: 'Health', type: 'expense', icon: 'HeartPulse', color: '#ec4899', transactionCount: 2 },
  { id: 'cat-other', name: 'Other', type: 'expense', icon: 'MoreHorizontal', color: '#6b7280', transactionCount: 10 }
];

const generateInitialEvents = (): Event[] => {
  const baseEvents: Event[] = [
    {
      id: 'evt-summer',
      name: 'Summer Vacation',
      budget: 5000,
      spent: 3150,
      dateRange: 'July 2026',
      description: 'Summer trip 21 days across Europe.',
      icon: 'Plane',
      status: 'active',
      daysCount: 'Day 12 of 21 • On track',
      type: 'expense'
    },
    {
      id: 'evt-holiday',
      name: 'Holiday Fund',
      budget: 5000,
      spent: 3200,
      dateRange: 'December 2026',
      description: 'Saving for Christmas & New Year family gatherings.',
      icon: 'Gift',
      status: 'upcoming',
      daysCount: 'Preparing for December holidays',
      type: 'expense'
    },
    {
      id: 'evt-anniversary',
      name: 'Wedding Anniversary',
      budget: 500,
      spent: 450,
      dateRange: 'Oct 24, 2026',
      description: 'An eligible anniversary romantic dinner & gift.',
      icon: 'Heart',
      status: 'upcoming',
      type: 'expense'
    },
    {
      id: 'evt-hiking',
      name: 'Weekend Hiking',
      budget: 300,
      spent: 120,
      dateRange: 'Oct 18-20, 2026',
      description: 'Trip to Vung Tau / Ho Tram with the close crew.',
      icon: 'Compass',
      status: 'upcoming',
      type: 'expense'
    },
    {
      id: 'evt-tech',
      name: 'Tech Conference',
      budget: 1000,
      spent: 1100,
      dateRange: 'Oct 28-30, 2026',
      description: 'Professional development workshop.',
      icon: 'Terminal',
      status: 'upcoming',
      type: 'expense'
    },
    {
      id: 'evt-birthday',
      name: 'Sam\'s Birthday',
      budget: 150,
      spent: 45,
      dateRange: 'Nov 02, 2026',
      description: 'Gifts & birthday surprise cupcakes.',
      icon: 'Cake',
      status: 'upcoming',
      type: 'expense'
    },
    {
      id: 'evt-expensive',
      name: 'Expensive MMYYYY',
      budget: 9000,
      spent: 4500,
      dateRange: 'Jun 2026 - Jul 2026',
      description: 'Primary container for high-value tracking.',
      icon: 'TrendingUp',
      status: 'completed',
      type: 'expense'
    },
    {
      id: 'evt-travel-vungtau',
      name: 'Travel Vung Tau 062024',
      budget: 2000,
      spent: 1980,
      dateRange: 'Jun 2024 - Jun 2024',
      description: 'Primary container for travel budgeting.',
      icon: 'Anchor',
      status: 'completed',
      type: 'expense'
    },
    {
      id: 'evt-house-doc',
      name: 'House Document',
      budget: 10000,
      spent: 6000,
      dateRange: 'Ongoing',
      description: 'Primary container for property fees.',
      icon: 'FileText',
      status: 'active',
      type: 'expense'
    }
  ];

  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const baseMonthlyProps: { [year: string]: Array<{ baseIncome: number; spent: number }> } = {
    '2026': [
      { baseIncome: 3000, spent: 1200 },
      { baseIncome: 3000, spent: 1350 },
      { baseIncome: 3000, spent: 1400 },
      { baseIncome: 3200, spent: 1550 },
      { baseIncome: 3200, spent: 1600 },
      { baseIncome: 3500, spent: 1800 },
      { baseIncome: 3500, spent: 1900 },
      { baseIncome: 3500, spent: 1100 },
      { baseIncome: 3800, spent: 1250 },
      { baseIncome: 3800, spent: 1300 },
      { baseIncome: 3800, spent: 1150 },
      { baseIncome: 4000, spent: 1565 }
    ],
    '2025': [
      { baseIncome: 2800, spent: 1300 },
      { baseIncome: 2800, spent: 1280 },
      { baseIncome: 2800, spent: 1350 },
      { baseIncome: 2800, spent: 1220 },
      { baseIncome: 3000, spent: 1450 },
      { baseIncome: 3000, spent: 1550 },
      { baseIncome: 3000, spent: 1900 },
      { baseIncome: 3000, spent: 1350 },
      { baseIncome: 3000, spent: 1200 },
      { baseIncome: 3000, spent: 1320 },
      { baseIncome: 3000, spent: 1150 },
      { baseIncome: 3200, spent: 1150 }
    ],
    '2024': [
      { baseIncome: 2400, spent: 1170 },
      { baseIncome: 2400, spent: 1160 },
      { baseIncome: 2400, spent: 1210 },
      { baseIncome: 2400, spent: 1200 },
      { baseIncome: 2400, spent: 1250 },
      { baseIncome: 2400, spent: 1240 },
      { baseIncome: 2600, spent: 1370 },
      { baseIncome: 2600, spent: 1240 },
      { baseIncome: 2600, spent: 1250 },
      { baseIncome: 2600, spent: 1190 },
      { baseIncome: 2605, spent: 1200 },
      { baseIncome: 2600, spent: 1270 }
    ]
  };

  const generated: Event[] = [...baseEvents];

  Object.entries(baseMonthlyProps).forEach(([year, monthlyValues]) => {
    monthlyValues.forEach((item, idx) => {
      const monthName = months[idx];
      
      // Add Real Event for Income
      generated.push({
        id: `evt-income-${year}-${idx}`,
        name: `${monthName} ${year} Business Salary`,
        budget: item.baseIncome,
        spent: 0,
        dateRange: `${monthName} ${year}`,
        description: `Salary payout for ${monthName} ${year}`,
        icon: 'TrendingUp',
        status: parseInt(year) < 2026 || (year === '2026' && idx <= 5) ? 'completed' : 'upcoming',
        type: 'income'
      });
      
      // Add Real Event for Expense
      generated.push({
        id: `evt-spent-${year}-${idx}`,
        name: `${monthName} ${year} General Expense`,
        budget: item.spent,
        spent: item.spent,
        dateRange: `${monthName} ${year}`,
        description: `Outflow and living costs for ${monthName} ${year}`,
        icon: 'FileText',
        status: parseInt(year) < 2026 || (year === '2026' && idx <= 5) ? 'completed' : 'upcoming',
        type: 'expense'
      });
    });
  });

  return generated;
};

export const INITIAL_EVENTS: Event[] = generateInitialEvents();

export const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: 'tx-1',
    title: 'Salary Deposit',
    amount: 4250.00,
    type: 'income',
    date: '2026-06-01',
    categoryId: 'cat-other',
    eventId: 'evt-house-doc',
    isRecurring: true,
    frequency: 'monthly',
    note: 'Initial monthly payout with bonuses.',
    vendor: 'Corp Employer'
  },
  {
    id: 'tx-2',
    title: 'Artisan Kitchen',
    amount: 42.30,
    type: 'expense',
    date: '2026-06-01',
    categoryId: 'cat-dining',
    eventId: 'evt-summer',
    isRecurring: false,
    note: 'Delightful brunch with the partner.',
    vendor: 'Artisan Culinary'
  },
  {
    id: 'tx-3',
    title: 'Minimalist Store',
    amount: 120.00,
    type: 'expense',
    date: '2026-05-31',
    categoryId: 'cat-groceries',
    eventId: 'evt-summer',
    isRecurring: false,
    note: 'High fidelity interior components & organizers.',
    vendor: 'Minimalist Store'
  },
  {
    id: 'tx-4',
    title: 'Shell Station',
    amount: 65.00,
    type: 'expense',
    date: '2026-05-31',
    categoryId: 'cat-transport',
    eventId: 'evt-summer',
    isRecurring: false,
    note: 'Gas tank refill on outbound journey.',
    vendor: 'Shell Station'
  },
  {
    id: 'tx-5',
    title: 'Stock Dividends',
    amount: 15.45,
    type: 'income',
    date: '2026-05-30',
    categoryId: 'cat-other',
    eventId: 'evt-house-doc',
    isRecurring: true,
    frequency: 'monthly',
    note: 'Monthly yield from exchange fund portfolios.',
    vendor: 'Finance Trade Corp'
  },
  {
    id: 'tx-6',
    title: 'Flight tickets',
    amount: 1200.00,
    type: 'expense',
    date: '2026-05-25',
    categoryId: 'cat-housing',
    eventId: 'evt-summer',
    isRecurring: false,
    note: 'Inbound travel tickets.',
    vendor: 'Skyline Airlines'
  },
  {
    id: 'tx-7',
    title: 'Dining & Local Food',
    amount: 450.25,
    type: 'expense',
    date: '2026-05-26',
    categoryId: 'cat-dining',
    eventId: 'evt-summer',
    isRecurring: false,
    note: 'Traditional dishes and refreshments.',
    vendor: 'Local Bistros'
  },
  {
    id: 'tx-8',
    title: 'Excursions & Entry fee',
    amount: 180.00,
    type: 'expense',
    date: '2026-05-27',
    categoryId: 'cat-transport',
    eventId: 'evt-summer',
    isRecurring: false,
    note: 'Museum tickets and boat tour booking.',
    vendor: 'Tourism Board'
  }
];

export function loadData<T>(key: string, backup: T): T {
  try {
    const data = localStorage.getItem(`clarity_finance_${key}`);
    return data ? JSON.parse(data) : backup;
  } catch (e) {
    return backup;
  }
}

export function saveData<T>(key: string, data: T): void {
  try {
    localStorage.setItem(`clarity_finance_${key}`, JSON.stringify(data));
  } catch (e) {
    console.error(e);
  }
}
