export interface Event {
  id: string;
  name: string;
  budget: number;
  spent: number;
  dateRange: string;
  description: string;
  icon: string;
  status: 'active' | 'upcoming' | 'completed';
  daysCount?: string;
  type?: 'income' | 'expense';
}

export interface Category {
  id: string;
  name: string;
  type: 'expense' | 'income';
  icon: string;
  color: string;
  transactionCount: number;
}

export interface Transaction {
  id: string;
  title: string;
  amount: number;
  type: 'income' | 'expense';
  date: string;
  categoryId: string;
  eventId: string;
  isRecurring: boolean;
  frequency?: 'weekly' | 'monthly' | 'yearly';
  note?: string;
  vendor?: string;
  receiptPhoto?: string;
  currency?: string;
}

export type ScreenType =
  | 'EVENT_OVERVIEW'
  | 'LOG_TRANSACTION'
  | 'TRANSACTION_LEDGER'
  | 'EVENT_BUDGET_PLANNER'
  | 'EVENT_BUDGET_DETAIL'
  | 'MANAGE_EVENTS'
  | 'MANAGE_CATEGORIES'
  | 'YEARLY_SUMMARY';
